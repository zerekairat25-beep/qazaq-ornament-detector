import { n as ORNAMENTS, t as CATEGORIES } from "./ornaments-ClDQPi3C.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useI18n } from "./router-CJZuxMDe.mjs";
import { a as Shell, i as OrnamentMark, n as Frieze, r as Medallion, t as Btn } from "./shell-CaHBhDP-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DoViXAri.js
var import_jsx_runtime = require_jsx_runtime();
var FEATURED = [
	"qoshqar-muyiz",
	"tumarsha",
	"qusqanat",
	"tuyetaban",
	"tortqulaq",
	"kun"
];
function Home() {
	const { t } = useI18n();
	const featured = FEATURED.map((id) => ORNAMENTS.find((item) => item.id === id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "bg-fg text-bg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-center gap-8 px-4 py-14 md:grid-cols-2 md:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "order-2 md:order-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "enter text-xs font-semibold tracking-widest text-accent uppercase",
							children: "Qazaq Ornament AI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "enter enter-2 mt-4 font-display text-5xl leading-none text-bg md:text-7xl",
							children: t({
								en: "Name the ornament. Keep the meaning.",
								kk: "Оюды ата. Мағынасын қалдыр."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "enter enter-3 mt-5 max-w-xl text-base leading-relaxed text-bg/80",
							children: t({
								en: "Kazakh oyu-örnek, read the way the study sets it out: Janibekov’s classes, a standard record for each motif, then a picture you can ask about.",
								kk: "Қазақ ою-өрнегі зерттеудегі ретпен: Жәнібеков жіктеуі, әр өрнектің стандартты карточкасы, сосын сұрауға болатын сурет."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								href: "/identify",
								children: t({
									en: "Identify a photo",
									kk: "Суретті тану"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/atlas",
								className: "inline-flex min-h-11 items-center justify-center border border-bg/30 px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
								children: t({
									en: "Open the atlas",
									kk: "Жинақты ашу"
								})
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "order-1 flex justify-center md:order-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Medallion, { className: "enter size-64 text-accent md:size-80" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frieze, { className: "h-7 w-full text-accent" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl",
					children: t({
						en: "Three jobs, one desk",
						kk: "Үш міндет, бір үстел"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-muted",
					children: t({
						en: "The study’s result is not a label by itself. Recognition, meaning, and plain speech stay together.",
						kk: "Зерттеудің нәтижесі — жалаң атау емес. Тану, мағына және қарапайым сөз бірге тұрады."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-4 md:grid-cols-3",
					children: [
						{
							n: "01",
							title: {
								en: "See the form",
								kk: "Пішінді көру"
							},
							body: {
								en: "A photo goes in. The motif is matched by its contour: horn, triangle, wing, track.",
								kk: "Сурет кіреді. Өрнек контурымен сәйкеседі: мүйіз, үшбұрыш, қанат, із."
							}
						},
						{
							n: "02",
							title: {
								en: "Attach the record",
								kk: "Карточканы қосу"
							},
							body: {
								en: "The name pulls a fixed card: category, symmetry, meaning, and where the motif sits on an object.",
								kk: "Атау бекітілген карточканы ашады: санат, симметрия, мағына және бұйымдағы орны."
							}
						},
						{
							n: "03",
							title: {
								en: "Say it plainly",
								kk: "Анық айту"
							},
							body: {
								en: "The screen gives the traditional name and the sense, in Kazakh or English, without a fog of jargon.",
								kk: "Экран дәстүрлі атау мен мәнін қазақша не ағылшынша, термин тұманынсыз береді."
							}
						}
					].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl text-accent",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 text-2xl",
								children: t(step.title)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: t(step.body)
							})
						]
					}, step.n))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl gap-8 px-4 py-14 md:grid-cols-4",
				children: [
					{
						k: "40+",
						v: {
							en: "motif types gathered from the ethnographic literature before the set was standardized",
							kk: "стандарттаудан бұрын этнографиялық әдебиеттен жиналған өрнек түрі"
						}
					},
					{
						k: "19/20",
						v: {
							en: "qoshqar muyiz images named correctly in the control set",
							kk: "бақылау жиынында дұрыс аталған қошқармүйіз суреті"
						}
					},
					{
						k: "38 → 92",
						v: {
							en: "percent who could name motifs before, then after, using the system",
							kk: "жүйені қолданғанға дейін және кейін өрнек атауын білгендердің пайызы"
						}
					},
					{
						k: "4",
						v: {
							en: "Janibekov classes: animal, plant, geometric, sky",
							kk: "Жәнібеков тобы: жануар, өсімдік, геометрия, аспан"
						}
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-5xl tabular-nums text-primary",
					children: item.k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: t(item.v)
				})] }, item.k))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-14",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl",
					children: t({
						en: "Start with six",
						kk: "Алтыдан бастаңыз"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					href: "/atlas",
					tone: "ghost",
					children: t({
						en: "All motifs",
						kk: "Барлық өрнек"
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid grid-cols-2 gap-3 md:grid-cols-3",
				children: featured.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/atlas",
					hash: item.id,
					className: "flex h-full flex-col border border-line bg-surface p-4 transition-transform duration-150 ease-out active:scale-[0.96]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
							id: item.id,
							className: "size-24",
							title: t(item.name)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-2xl",
							children: t(item.name)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: t(item.gloss)
						})
					]
				}) }, item.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl",
				children: t({
					en: "Four families",
					kk: "Төрт әулет"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-3 md:grid-cols-4",
				children: CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/atlas",
					search: { cat: cat.id },
					className: "border border-line p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-2xl",
						children: t(cat.label)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: t(cat.note)
					})]
				}, cat.id))
			})]
		})
	] });
}
//#endregion
export { Home as component };
