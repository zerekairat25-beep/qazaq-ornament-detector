import { i as __toESM } from "../_runtime.mjs";
import { n as ORNAMENTS } from "./ornaments-ClDQPi3C.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useI18n } from "./router-CJZuxMDe.mjs";
import { a as Shell } from "./shell-CaHBhDP-.mjs";
import { a as Bar, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research-Buw5v0rU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CONTROLS = ORNAMENTS.filter((item) => item.control);
function ResearchPage() {
	const { t, lang } = useI18n();
	const accuracy = CONTROLS.map((item) => ({
		name: lang === "kk" ? item.name.kk : item.gloss.en,
		counts: Math.round(item.control.correct / item.control.images * 100),
		printed: item.control.printed
	}));
	const learning = [
		{
			name: t({
				en: "Names",
				kk: "Атауы"
			}),
			before: 38,
			after: 92
		},
		{
			name: t({
				en: "Meaning",
				kk: "Мағына"
			}),
			before: 24,
			after: 85
		},
		{
			name: t({
				en: "Context",
				kk: "Контекст"
			}),
			before: 31,
			after: 88
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-accent uppercase",
				children: t({
					en: "The study",
					kk: "Зерттеу"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 max-w-3xl font-display text-5xl leading-none md:text-6xl",
				children: t({
					en: "From the literature to a desk that answers",
					kk: "Әдебиеттен жауап беретін үстелге"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-muted",
				children: t({
					en: "Every step of the Qazaq Ornament study is on this page. Numbers are the ones written in that work. Where a printed percent does not match the count beside it, both are shown.",
					kk: "Qazaq Ornament зерттеуінің әр қадамы осы бетте. Сандар сол жұмыстағыдай. Басылған пайыз қасындағы санаққа сай келмесе, екеуі де көрсетіледі."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				kicker: "1.1",
				title: {
					en: "Reading the ethnographic literature",
					kk: "Этнографиялық әдебиетті оқу"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "The first pass was historical, cultural, and symbolic. Özbekali Janibekov’s work is the spine: «Қазақтың ұлттық қолөнері» and «Жаңғырық». He sorts ornaments by origin and by where they sit on the yurt, in jewelry, and in weaving.",
						kk: "Алғашқы өту тарихи, мәдени және символдық. Өзегі — Өзбекәлі Жәнібеков: «Қазақтың ұлттық қолөнері» және «Жаңғырық». Ол өрнекті шығу тегі және киіз үйдегі, зергерліктегі, тоқымадағы орны бойынша ажыратады."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "Drawings and notes were also taken from jewelry studies and from «Қошетер» and related craft books. They were then split by Janibekov’s four motifs: animals, plants, geometry, and heavenly bodies.",
						kk: "Сурет пен жазба зергерлік еңбектерден, «Қошетер» және туыс қолөнер кітаптарынан да алынды. Сосын Жәнібековтің төрт мотивіне бөлінді: жануар, өсімдік, геометрия, аспан денелері."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "A motif was not kept for its outline alone. Name, structure, sense, and use were recorded together. Qoshqar muyiz is the curled horn of prosperity and strength. Tumarsha is the triangular amulet against the evil eye. Qusqanat is the wing of freedom, height, and a good wish. More than forty types were gathered the same way.",
						kk: "Өрнек тек сұлбасы үшін сақталмады. Атауы, құрылымы, мәні және қолданысы бірге жазылды. Қошқармүйіз — береке мен қуаттың иірім мүйізі. Тұмарша — тіл-көзге қарсы үшбұрыш тұмар. Құсқанат — еркіндік, биіктік және ізгі тілектің қанаты. Осылай қырықтан астам түрі жиналды."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "The conclusion of that pass: an ornament is not only decoration. Its form and its place belong to a worldview.",
						kk: "Сол кезеңнің қорытындысы: ою тек әшекей емес. Пішіні мен орны дүниетанымға тиесілі."
					}) })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				kicker: "1.2",
				title: {
					en: "One standard for the set",
					kk: "Жинақты бір стандартқа келтіру"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "So a model would not learn noise, the set was brought to one ethnographic and digital standard. Visually distinct types were kept. Each had at least ten pictures, each picture labeled with its class name.",
						kk: "Модель шуды жаттамауы үшін жинақ бір этнографиялық және цифрлық стандартқа келтірілді. Пішіні бөлек түрлер қалды. Әрқайсысына кемі он сурет, әр сурет класс атауымен белгіленді."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-2xl",
								children: t({
									en: "Picture standard",
									kk: "Сурет стандарты"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
										en: "Scaled to 224×224, with noise and stray background removed.",
										kk: "224×224 өлшемге келтірілді, шу мен артық фон алынды."
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
										en: "Contours and symmetry axes taken into a vector form.",
										kk: "Контур мен симметрия осі векторлық пішінге түсірілді."
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
										en: "Augmented by rotation, brightness, and contrast, so the net would generalize.",
										kk: "Бұру, жарық және контрастпен кеңейтілді — желі жалпылауы үшін."
									}) })
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line bg-surface p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-2xl",
								children: t({
									en: "Card for each motif",
									kk: "Әр өрнектің карточкасы"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 space-y-2 text-sm leading-relaxed text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
										en: "Name, category, graphic form, symmetry.",
										kk: "Атауы, категориясы, графикалық пішіні, симметриясы."
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
										en: "Meaning, where it is used, and a source code back to the literature.",
										kk: "Мәні, қолданылатын жері және әдебиеттегі дереккөз коды."
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
										en: "Example card: qoshqar muyiz, zoomorphic, spiral-arc curls, bilateral, abundance, center of a carpet. Janibekov, 1982.",
										kk: "Үлгі: қошқармүйіз, зооморфты, спираль-доға, екі жақты, молшылық, кілемнің ортасы. Жәнібеков, 1982."
									}) })
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4",
						children: t({
							en: "The point of the card is that the model is not left to memorize pixels. Symmetry and topology stay attached to the name.",
							kk: "Карточканың мәні — модельді пиксель жаттаумен шектемеу. Симметрия мен топология атауға бекітіледі."
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				kicker: "2.1",
				title: {
					en: "Naming a picture",
					kk: "Суретті атау"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "Input: a digital image. Output: the name, the semantic class, and a confidence score. Held-out images, never used in training, were the test.",
						kk: "Кіріс: цифрлық кескін. Шығыс: атауы, семантикалық класы және сенімділік. Оқытуға кірмеген бақылау суреттері сынақ болды."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-4 grid gap-3 md:grid-cols-2",
						children: [
							{
								t: {
									en: "Accuracy",
									kk: "Accuracy — жалпы дәлдік"
								},
								d: {
									en: "Share of all test images named correctly.",
									kk: "Барлық сынақ суретінің ішінде дұрыс аталғанының үлесі."
								}
							},
							{
								t: {
									en: "Precision",
									kk: "Precision — нақтылық"
								},
								d: {
									en: "Of the images called a given class, how many truly were.",
									kk: "Берілген класс деп аталғандардың ішінде шынымен солар болғаны."
								}
							},
							{
								t: {
									en: "Recall",
									kk: "Recall — толықтық"
								},
								d: {
									en: "Of the images that truly belong to a class, how many were found.",
									kk: "Кластың нақты суреттерінің қаншасы табылғаны."
								}
							},
							{
								t: {
									en: "F1",
									kk: "F1-Score"
								},
								d: {
									en: "The harmonic mean of precision and recall.",
									kk: "Precision мен recall-дың гармониялық ортасы."
								}
							}
						].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-display text-2xl",
								children: t(item.t)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-sm text-muted",
								children: t(item.d)
							})]
						}, item.t.en))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[36rem] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b border-line text-xs tracking-wide text-muted uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Class",
											kk: "Класс"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Images",
											kk: "Сурет"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Correct",
											kk: "Дұрыс"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Wrong",
											kk: "Қате"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "From the counts",
											kk: "Санақтан"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-medium",
										children: t({
											en: "Printed",
											kk: "Басылғаны"
										})
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: CONTROLS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: t(item.name)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3 tabular-nums",
										children: item.control.images
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3 tabular-nums",
										children: item.control.correct
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3 tabular-nums",
										children: item.control.wrong
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 pr-3 tabular-nums",
										children: [Math.round(item.control.correct / item.control.images * 100), "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-3 tabular-nums",
										children: [item.control.printed, "%"]
									})
								]
							}, item.id)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: t({
							en: "Correct over twenty: 95, 90, 90, 95, and 85. That is 91 of 100 images, and a mean of 91%. The write-up prints 95, 91, 88, 93, 86 and calls the average 90.6%. Qusqanat and synar muyiz are where the printed figure and the count disagree. The counts are kept as the record.",
							kk: "Жиырмаға бөлгенде: 95, 90, 90, 95 және 85. Бұл 100-дің 91-і, орташа 91%. Мәтінде 95, 91, 88, 93, 86 және орташа 90.6% деп тұр. Құсқанат пен сыңармүйізде басылған сан мен санақ сәйкеспейді. Дерек ретінде санақ сақталды."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-72",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientChart, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: accuracy,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--color-line)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, 100],
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "var(--color-line)" },
										contentStyle: {
											background: "var(--color-surface)",
											border: "1px solid var(--color-line)",
											borderRadius: 0
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "counts",
										fill: "var(--color-primary)",
										name: t({
											en: "From counts",
											kk: "Санақтан"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "printed",
										fill: "var(--color-accent)",
										name: t({
											en: "Printed",
											kk: "Басылғаны"
										})
									})
								]
							})
						}) })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				kicker: "2.2",
				title: {
					en: "Training, then the web",
					kk: "Оқыту, сосын веб"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "Curved, spiral, symmetric marks were given to a convolutional net. ResNet or MobileNet was modified so a phone and a browser could carry it. Train and validation curves were watched for over-fitting and under-fitting. Weights were saved at the best accuracy.",
						kk: "Иірім, шиыршық, симметриялы белгілер конволюциялық желіге берілді. Телефон мен браузер көтере алатындай ResNet не MobileNet өзгертілді. Оқыту мен валидация қисығы қайта оқып кету мен жеткіліксіз оқылуға қаралды. Салмақ ең жоғары дәлдікте сақталды."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b border-line text-xs tracking-wide text-muted uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Parameter",
											kk: "Параметр"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Role",
											kk: "Міндеті"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-medium",
										children: t({
											en: "Chosen",
											kk: "Таңдалғаны"
										})
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
								[
									"Loss",
									{
										en: "Loss function",
										kk: "Шығын функциясы"
									},
									"Categorical cross-entropy"
								],
								[
									"Optimizer",
									{
										en: "Optimizer",
										kk: "Оптимизатор"
									},
									"Adam"
								],
								[
									"Epochs",
									{
										en: "Training epochs",
										kk: "Оқыту дәуірі"
									},
									"50–100"
								],
								[
									"Learning rate",
									{
										en: "Learning rate",
										kk: "Оқыту жылдамдығы"
									},
									"0.001"
								]
							].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: row[0]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: t(row[1])
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3",
										children: row[2]
									})
								]
							}, row[0])) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4",
						children: t({
							en: "The saved model sat behind a small REST service (FastAPI or Flask). A visitor posts a picture. The service resizes it, returns a class and a confidence, and the back end fills the card from the Janibekov record: name, sense, form, and use.",
							kk: "Сақталған модель шағын REST қызметінің артында тұрды (FastAPI не Flask). Қонақ суретті POST етеді. Қызмет өлшемін келтіреді, класс пен сенімділікті қайтарады, бэкенд Жәнібеков деректерінен карточканы толтырады: атау, мән, пішін, қолданыс."
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				kicker: "3",
				title: {
					en: "Three checks",
					kk: "Үш тексеру"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-3xl",
						children: t({
							en: "Against other tools",
							kk: "Басқа құралдармен"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: t({
							en: "Qazaq Ornament was set beside Google Lens and ChatGPT. A plus is a full yes, a dash is no, and a mixed mark is partial.",
							kk: "Qazaq Ornament Google Lens және ChatGPT-пен қатар қойылды. Плюс — толық иә, сызық — жоқ, аралас белгі — ішінара."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[40rem] text-left text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "border-b border-line text-xs tracking-wide text-muted uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: t({
											en: "Criterion",
											kk: "Критерий"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: "Qazaq Ornament"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 pr-3 font-medium",
										children: "Google Lens"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "py-2 font-medium",
										children: "ChatGPT"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [
								[
									{
										en: "Seeing a picture",
										kk: "Сурет арқылы көру"
									},
									"yes",
									"part",
									"part"
								],
								[
									{
										en: "A Kazakh ornament classification",
										kk: "Қазақ оюын арнайы жіктеу"
									},
									"yes",
									"part",
									"part"
								],
								[
									{
										en: "Explaining the meaning",
										kk: "Семантикалық мағынасын түсіндіру"
									},
									"yes",
									"no",
									"no"
								],
								[
									{
										en: "Opening the cultural context",
										kk: "Этномәдени контексті ашу"
									},
									"yes",
									"no",
									"part"
								],
								[
									{
										en: "Academic Kazakh",
										kk: "Қазақша академиялық сапа"
									},
									"yes",
									"part",
									"part"
								],
								[
									{
										en: "Tied to a cultural dataset",
										kk: "Мәдени деректер базасымен байланыс"
									},
									"yes",
									"no",
									"no"
								]
							].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: t(row[0])
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: mark(row[1], t)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3 pr-3",
										children: mark(row[2], t)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-3",
										children: mark(row[3], t)
									})
								]
							}, row[0].en)) })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-8 font-display text-3xl",
						children: t({
							en: "Against the books",
							kk: "Кітаптармен"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: t({
							en: "To keep the system from inventing a fact, each card was checked against academic descriptions: the scholarly name and regional aliases, the form and the symbol, and how it is used on tekemet, carpet, jewelry, and dress. Where sources disagreed, only a description that points at its source was kept.",
							kk: "Жүйе расталмаған деректі айтпауы үшін әр карточка академиялық сипаттамамен салыстырылды: ғылыми атауы мен аймақтық баламасы, пішіні мен символы, текемет, кілем, зергерлік және киімдегі қолданысы. Дереккөздер қайшы келсе, тек дереккөзі көрсетілген сипаттама қалды."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-8 font-display text-3xl",
						children: t({
							en: "Before and after, ages 12–30",
							kk: "Дейін және кейін, 12–30 жас"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: t({
							en: "People answered once before using the system and once after. The study does not print how many people sat the test. It does print these shares of correct answers.",
							kk: "Адамдар жүйені қолданбас бұрын бір рет, қолданған соң бір рет жауап берді. Зерттеу қанша адам қатысқанын жазбайды. Дұрыс жауап үлесін жазады."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientChart, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: learning,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--color-line)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "name",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [0, 100],
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "var(--color-line)" },
										contentStyle: {
											background: "var(--color-surface)",
											border: "1px solid var(--color-line)",
											borderRadius: 0
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "before",
										fill: "var(--color-accent)",
										name: t({
											en: "Before",
											kk: "Дейін"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "after",
										fill: "var(--color-primary)",
										name: t({
											en: "After",
											kk: "Кейін"
										})
									})
								]
							})
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 grid gap-2 text-sm text-muted md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
								en: "Names: 38% to 92% (+54)",
								kk: "Атауы: 38%-дан 92%-ға (+54)"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
								en: "Meaning: 24% to 85% (+61)",
								kk: "Мағына: 24%-дан 85%-ға (+61)"
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: t({
								en: "Context and use: 31% to 88% (+57)",
								kk: "Контекст пен қолданыс: 31%-дан 88%-ға (+57)"
							}) })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				kicker: "4",
				title: {
					en: "What held, and what failed",
					kk: "Не тұрды, не сынды"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "The system had to do three things at once: name a motif from its looks, tie that name to a cultural description, and show the result in plain speech.",
						kk: "Жүйе үш нәрсені бірге істеуі керек еді: өрнекті түрінен атау, атауды мәдени сипаттамаға байлау және нәтижені қарапайым сөзбен көрсету."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "Digitizing an ornament is not the same as classifying a picture. The comparison’s real advantage is that identification and ethnographic explanation travel together. Lens and a general chat model do not carry this dataset.",
						kk: "Оюды цифрлау суретті жіктеумен бітпейді. Салыстырудағы нақты артықшылық — тану мен этнографиялық түсіндірме бірге жүреді. Lens пен жалпы чат моделінде бұл деректер базасы жоқ."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t({
						en: "The model did miss. Motifs with similar structure were confused. Photo quality and the angle of the shot moved the result. The study’s own next step is more pictures and a larger set. The rise on the second test is what the authors take as evidence that the desk can teach.",
						kk: "Модель қателесті. Құрылымы ұқсас өрнектер шатасты. Сурет сапасы мен бұрышы нәтижені жылжытты. Зерттеудің келесі қадамы — көбірек сурет және үлкенірек жинақ. Екінші сынақтағы өсуді авторлар үстелдің үйрете алатынының дәлелі деп алады."
					}) })
				]
			})
		]
	}) });
}
function Section({ kicker, title, children }) {
	const { t } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-12 border-t border-line pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl text-accent",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-4xl",
				children: t(title)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 max-w-3xl space-y-3 text-sm leading-relaxed",
				children
			})
		]
	});
}
function mark(kind, t) {
	if (kind === "yes") return t({
		en: "Yes",
		kk: "Иә"
	});
	if (kind === "no") return t({
		en: "No",
		kk: "Жоқ"
	});
	return t({
		en: "Partial",
		kk: "Ішінара"
	});
}
function ClientChart({ children }) {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full bg-surface" });
	return children;
}
//#endregion
export { ResearchPage as component };
