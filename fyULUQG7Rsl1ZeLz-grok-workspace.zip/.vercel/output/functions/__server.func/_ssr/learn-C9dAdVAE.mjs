import { i as __toESM } from "../_runtime.mjs";
import { n as ORNAMENTS } from "./ornaments-ClDQPi3C.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useI18n } from "./router-CJZuxMDe.mjs";
import { a as Shell, i as OrnamentMark, o as cn, t as Btn } from "./shell-CaHBhDP-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-C9dAdVAE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LearnPage() {
	const { t } = useI18n();
	const [seed, setSeed] = (0, import_react.useState)(null);
	const [step, setStep] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [score, setScore] = (0, import_react.useState)(0);
	const [best, setBest] = (0, import_react.useState)(null);
	const questions = (0, import_react.useMemo)(() => seed === null ? [] : buildQuiz(seed), [seed]);
	const current = questions[step];
	const done = seed !== null && step >= questions.length;
	function start() {
		const stored = Number(localStorage.getItem("qo-best"));
		setBest(Number.isFinite(stored) ? stored : null);
		setSeed(Date.now());
		setStep(0);
		setPicked(null);
		setScore(0);
	}
	function choose(id) {
		if (!current || picked) return;
		setPicked(id);
		if (id === current.ornament.id) setScore((value) => value + 1);
	}
	function next() {
		if (step + 1 >= questions.length) {
			const finalScore = score;
			const stored = Number(localStorage.getItem("qo-best"));
			if (finalScore > (Number.isFinite(stored) ? stored : 0)) {
				localStorage.setItem("qo-best", String(finalScore));
				setBest(finalScore);
			} else if (Number.isFinite(stored)) setBest(stored);
		}
		setStep((value) => value + 1);
		setPicked(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-accent uppercase",
				children: t({
					en: "The learning check",
					kk: "Білім сынағы"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: t({
					en: "Name it, then say what it holds",
					kk: "Атаңыз, сосын не ұстайтынын айтыңыз"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: t({
					en: "The study gave the same kind of check before and after people used the system. Names rose from 38% to 92%, meanings from 24% to 85%, context from 31% to 88%. This round is eight questions from the atlas. It is practice, not that experiment.",
					kk: "Зерттеу адамдарға жүйені қолданғанға дейін және кейін осы тектес сынақ берген. Атау 38%-дан 92%-ға, мағына 24%-дан 85%-ға, контекст 31%-дан 88%-ға көтерілген. Бұл раунд — жинақтан сегіз сұрақ. Жаттығу, сол эксперимент емес."
				})
			}),
			seed === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					onClick: start,
					children: t({
						en: "Start eight questions",
						kk: "Сегіз сұрақты бастау"
					})
				})
			}) : null,
			current && !done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold text-muted tabular-nums",
						children: [
							step + 1,
							" / ",
							questions.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
							id: current.ornament.id,
							className: "size-36",
							title: ""
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-center font-display text-3xl",
						children: current.kind === "name" ? t({
							en: "What is this called?",
							kk: "Бұл қалай аталады?"
						}) : t({
							en: "Which sense belongs to this form?",
							kk: "Бұл пішінге қай мән жатады?"
						})
					}),
					current.kind === "meaning" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-center text-muted",
						children: t(current.ornament.name)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 grid gap-2",
						children: current.options.map((option) => {
							const correct = option.id === current.ornament.id;
							const show = picked !== null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: picked !== null,
								onClick: () => choose(option.id),
								className: cn("min-h-11 w-full border px-3 py-3 text-left text-sm", !show && "border-line bg-bg", show && correct && "border-primary bg-primary text-primary-fg", show && picked === option.id && !correct && "border-fg bg-fg text-bg", show && picked !== option.id && !correct && "border-line text-muted"),
								children: current.kind === "name" ? t(option.name) : t(option.meaning)
							}) }, option.id);
						})
					}),
					picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: picked === current.ornament.id ? t({
								en: "Yes. That is the one.",
								kk: "Иә. Дәл осы."
							}) : t({
								en: "Not that one. The marked answer is the record.",
								kk: "Ол емес. Белгіленгені — дерек."
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: next,
							children: step + 1 === questions.length ? t({
								en: "See the score",
								kk: "Нәтижені көру"
							}) : t({
								en: "Next",
								kk: "Келесі"
							})
						})]
					}) : null
				]
			}) : null,
			done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 border border-line bg-fg p-6 text-bg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-6xl tabular-nums",
						children: [
							score,
							"/",
							questions.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-bg/80",
						children: t({
							en: "Eight is a short check. The study’s jump came after people had used the full desk, not after one round.",
							kk: "Сегіз — қысқа сынақ. Зерттеудегі секіріс адамдар толық үстелді қолданған соң болған, бір раундтан кейін емес."
						})
					}),
					best !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-accent",
						children: t({
							en: `Best on this device: ${best}/8`,
							kk: `Осы құрылғыдағы үздік: ${best}/8`
						})
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							onClick: start,
							children: t({
								en: "Try another round",
								kk: "Тағы бір раунд"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
							href: "/atlas",
							tone: "quiet",
							children: t({
								en: "Read the atlas",
								kk: "Жинақты оқу"
							})
						})]
					})
				]
			}) : null
		]
	}) });
}
function buildQuiz(seed) {
	const rand = mulberry32(seed);
	const pool = shuffle(ORNAMENTS, rand);
	const nameSet = pool.slice(0, 4);
	const meaningSet = pool.slice(4, 8);
	return shuffle([...nameSet.map((ornament) => ({
		kind: "name",
		ornament,
		options: withDecoys(ornament, pool, rand)
	})), ...meaningSet.map((ornament) => ({
		kind: "meaning",
		ornament,
		options: withDecoys(ornament, pool, rand)
	}))], rand);
}
function withDecoys(ornament, pool, rand) {
	const same = pool.filter((item) => item.id !== ornament.id && item.category === ornament.category);
	const rest = pool.filter((item) => item.id !== ornament.id && item.category !== ornament.category);
	return shuffle([ornament, ...shuffle([...same, ...rest], rand).slice(0, 3)], rand);
}
function shuffle(list, rand) {
	const copy = [...list];
	for (let i = copy.length - 1; i > 0; i -= 1) {
		const j = Math.floor(rand() * (i + 1));
		[copy[i], copy[j]] = [copy[j], copy[i]];
	}
	return copy;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return function rand() {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
//#endregion
export { LearnPage as component };
