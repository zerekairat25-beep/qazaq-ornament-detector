//#region node_modules/.nitro/vite/services/ssr/assets/ornaments-ClDQPi3C.js
var CATEGORIES = [
	{
		id: "zoomorphic",
		label: {
			en: "Animal",
			kk: "Жануар"
		},
		note: {
			en: "Horns, tracks, wings, eyes. Livestock was life, so these are the largest family.",
			kk: "Мүйіз, табан, қанат, көз. Төрт түлік тіршіліктің өзі болғандықтан, бұл ең үлкен топ."
		}
	},
	{
		id: "plant",
		label: {
			en: "Plant",
			kk: "Өсімдік"
		},
		note: {
			en: "Leaf, flower, tree. Growth, reduced to a repeatable cut.",
			kk: "Жапырақ, гүл, ағаш. Өсу — қайталанатын оюға жинақталған."
		}
	},
	{
		id: "geometric",
		label: {
			en: "Geometric",
			kk: "Геометриялық"
		},
		note: {
			en: "Triangle, square, meander, chain. Often a guardian sign or a border.",
			kk: "Үшбұрыш, шаршы, ирек, шынжыр. Көбіне қорғаныш белгі немесе жиек."
		}
	},
	{
		id: "cosmogonic",
		label: {
			en: "Sky",
			kk: "Аспан"
		},
		note: {
			en: "Sun, moon, star. Janibekov’s cosmogonic group: heavenly bodies.",
			kk: "Күн, ай, жұлдыз. Жәнібековтің космогониялық тобы — аспан денелері."
		}
	}
];
var ORNAMENTS = [
	{
		id: "qoshqar-muyiz",
		category: "zoomorphic",
		name: {
			en: "Qoshqar muyiz",
			kk: "Қошқармүйіз"
		},
		gloss: {
			en: "Ram’s horn",
			kk: "Қошқардың мүйізі"
		},
		form: {
			en: "A ram’s head reduced to a line. Horns curl out to both sides, two short joints stand in for the ears, and the snout is still readable. The older relative is the animal style of the Saka.",
			kk: "Қошқардың басы сызыққа жинақталған. Мүйіз екі жаққа иіріледі, қолтық тұсынан құлақтың шолақ буыны шығады, тұмсық пішіні де оқылады. Ескі туысы — сақтардың аң стилі."
		},
		meaning: {
			en: "Prosperity, abundance, and the increase of herd and household. Strength sits in the same sign: the four kinds of livestock were survival itself, so the horn is both power and qut, a blessing.",
			kk: "Береке, молшылық, мал мен шаңырақтың өсуі. Қуат та осы белгіде: төрт түлік өмірдің кепілі болған, сондықтан мүйіз әрі күш, әрі құт."
		},
		use: {
			en: "Center of a tekemet, syrmak, or carpet. Also baskur, alasha, leather, bone, wood, and jewelry.",
			kk: "Текемет, сырмақ, кілемнің ортасы. Сонымен бірге басқұр, алаша, былғары, сүйек, ағаш және зергерлік бұйым."
		},
		symmetry: {
			en: "Bilateral",
			kk: "Екі жақты симметрия"
		},
		visual: "bilateral pair of spiral ram horns with a readable snout between them, often a central medallion",
		studied: true,
		control: {
			images: 20,
			correct: 19,
			wrong: 1,
			printed: 95
		}
	},
	{
		id: "synar-muyiz",
		category: "zoomorphic",
		name: {
			en: "Synar muyiz",
			kk: "Сыңармүйіз"
		},
		gloss: {
			en: "Single horn",
			kk: "Жалғыз мүйіз"
		},
		form: {
			en: "Only one horn of the pair. It was repeated in a running row along the edge of felt and pile carpets, where a full ram face would not fit.",
			kk: "Қос мүйіздің бір сыңары ғана. Толық қошқар басы сыймайтын жерде — киіз бен түкті кілемнің жиегінде қатарлап салынған."
		},
		meaning: {
			en: "The motif itself is a single horn used as a border, not a second animal. Schoolbooks often read the unpaired horn as a singular character. That is a later teaching, not a separate ancient definition.",
			kk: "Өрнектің өзі — жиекке арналған жалғыз мүйіз, бөлек аң емес. Мектепте оны дара мінез деп оқу жиі. Бұл кейінгі оқыту, ежелгі бөлек анықтама емес."
		},
		use: {
			en: "Borders of felt textiles and carpets.",
			kk: "Киіз бұйым мен кілемнің жиегі."
		},
		symmetry: {
			en: "None — a one-sided repeat",
			kk: "Жоқ — біржақты қайталау"
		},
		visual: "a single spiral horn, not mirrored, repeated as a border",
		studied: true,
		control: {
			images: 20,
			correct: 17,
			wrong: 3,
			printed: 86
		}
	},
	{
		id: "qos-muyiz",
		category: "zoomorphic",
		name: {
			en: "Qos muyiz",
			kk: "Қосмүйіз"
		},
		gloss: {
			en: "Paired horns",
			kk: "Қос мүйіз"
		},
		form: {
			en: "Two horns side by side, recalling sheep, goat, or cattle. It does not build the full ram face of qoshqar muyiz.",
			kk: "Қатар тұрған екі мүйіз — қой, ешкі не сиыр мүйізін еске салады. Қошқармүйіздегідей толық бас құрамайды."
		},
		meaning: {
			en: "Paired fortune and accord: two that belong together.",
			kk: "Қосақталған құт пен татулық: бір-біріне тиесілі екеу."
		},
		use: {
			en: "Household objects, furniture, clothing, sometimes weapons.",
			kk: "Үй бұйымы, жиһаз, киім, кейде қару-жарақ."
		},
		symmetry: {
			en: "Bilateral pair",
			kk: "Қос симметрия"
		},
		visual: "two horns side by side as a couple, without a full ram face"
	},
	{
		id: "arqar-muyiz",
		category: "zoomorphic",
		name: {
			en: "Arqar muyiz",
			kk: "Арқармүйіз"
		},
		gloss: {
			en: "Argali horn",
			kk: "Арқар мүйізі"
		},
		form: {
			en: "The wild sheep’s horn. It resembles qoshqar muyiz but winds tighter and throws off more branches.",
			kk: "Арқардың мүйізі. Қошқармүйізге ұқсайды, бірақ шиыршығы тығыз, тармағы көбірек."
		},
		meaning: {
			en: "Strength and courage. The argali is a mountain animal, so the horn is read as stamina, not only as wealth.",
			kk: "Күш пен батылдық. Арқар — тау аңы, сондықтан мүйіз байлықтан бөлек төзімділікті де білдіреді."
		},
		use: {
			en: "Carpets, tuskiiz, syrmak, embroidery, clothing, furniture.",
			kk: "Кілем, түскиіз, сырмақ, кесте, киім, жиһаз."
		},
		symmetry: {
			en: "Bilateral, with extra branches",
			kk: "Екі жақты, қосымша тармақты"
		},
		visual: "tighter multi-turn wild-sheep horn with extra branches, more coiled than a simple ram horn"
	},
	{
		id: "qyryq-muyiz",
		category: "zoomorphic",
		name: {
			en: "Qyryq muyiz",
			kk: "Қырықмүйіз"
		},
		gloss: {
			en: "Many horns",
			kk: "Қырық мүйіз"
		},
		form: {
			en: "A horn split into many branches, packed inside a circle or a square. “Forty” here means a great many, not a count.",
			kk: "Көп тармаққа бөлінген мүйіз, дөңгелек не шаршының ішіне сыйғызылған. «Қырық» мұнда санақ емес, «өте көп» деген сөз."
		},
		meaning: {
			en: "Abundance and unity: many branches from one root.",
			kk: "Молшылық пен бірлік: бір түптен шыққан көп тармақ."
		},
		use: {
			en: "Tuskiiz, outer coats, syrmak, tekemet, and architectural ornament.",
			kk: "Түскиіз, сырт киім, сырмақ, текемет және сәулет өрнегі."
		},
		symmetry: {
			en: "Radial",
			kk: "Шоғырлы, радиалды"
		},
		visual: "many small horn-curls packed inside a circle or square"
	},
	{
		id: "synyq-muyiz",
		category: "zoomorphic",
		name: {
			en: "Synyq muyiz",
			kk: "Сынықмүйіз"
		},
		gloss: {
			en: "Folded horn",
			kk: "Сынық мүйіз"
		},
		form: {
			en: "A horn bent inward several times, about four folds, like a horn that has been broken and turned back.",
			kk: "Ішке қарай бірнеше, шамамен төрт рет иілген мүйіз — сынып, кері бұрылғандай."
		},
		meaning: {
			en: "The form is a bent horn. Popular teaching reads the folds as life changing direction and still going on. That reading is pedagogical.",
			kk: "Пішіні — бүгілген мүйіз. Мектепте бүктесінерді өмірдің бағыт ауыстырып, үзілмей жүре беруі деп оқиды. Бұл — оқулықтық оқылым."
		},
		use: {
			en: "Carpets, chi mats, baskur, and alasha.",
			kk: "Кілем, шымши, басқұр, алаша."
		},
		symmetry: {
			en: "Repeating folds",
			kk: "Қайталанатын иілім"
		},
		visual: "a horn folded inward several times with angular bends, not a smooth spiral"
	},
	{
		id: "maral-muyiz",
		category: "zoomorphic",
		name: {
			en: "Maral muyiz",
			kk: "Маралмүйіз"
		},
		gloss: {
			en: "Deer antler",
			kk: "Марал мүйізі"
		},
		form: {
			en: "A stylized deer antler. It branches. It does not curl into one ram spiral. The related bugy muyiz, a stag horn, is the one more often tied to raw power.",
			kk: "Маралдың стильденген мүйізі. Тармақталады, қошқардай бір шиыршыққа жиналмайды. Күш-қуатқа көбіне бұғымүйізді жатқызады."
		},
		meaning: {
			en: "Grace and beauty.",
			kk: "Сұлулық пен көркемдік."
		},
		use: {
			en: "Headdresses and clothing. Antler forms were also carved on horse gear.",
			kk: "Бас киім мен киім. Мүйіз үлгісі ат әбзеліне де ойылып салынған."
		},
		symmetry: {
			en: "Branching, roughly bilateral",
			kk: "Тармақты, шамамен екі жақты"
		},
		visual: "branching deer antler, not a single ram spiral"
	},
	{
		id: "tuyetaban",
		category: "zoomorphic",
		name: {
			en: "Tuyetaban",
			kk: "Түйетабан"
		},
		gloss: {
			en: "Camel track",
			kk: "Түйе табаны"
		},
		form: {
			en: "A camel’s footprint: two S-curves that come close and do not join, closing into two long ovals. It can be mistaken for qarta, qarga, or qyzyl-ayyr.",
			kk: "Түйенің ізі: бір-біріне жақындап, қосылмайтын екі S-сызық, екі сопақ жарты. Қарта, қарға, қызылайыр өрнектерімен шатасады."
		},
		meaning: {
			en: "Endurance, patience, and a long road. It was put on camel trappings and caravan gear. It also reads as a firm base: a yurt that does not shift.",
			kk: "Төзім, сабыр және алыс жол. Түйе жабуы мен керуен бұйымына салынған. Мызғымас негіз, орныққан шаңырақ деп те оқылады."
		},
		use: {
			en: "Camel covers, door lintels, yurt wood, felt. Later cutting guides also place it on trousers and footwear.",
			kk: "Түйе жабуы, маңдайша, үй ағашы, киіз. Кейінгі пішу нұсқаулығында шалбар мен аяқ киімге де түседі."
		},
		symmetry: {
			en: "Bilateral S-pair",
			kk: "Екі жақты S жұбы"
		},
		visual: "two facing S-curves making a split oval footprint, not a spiral horn",
		studied: true,
		control: {
			images: 20,
			correct: 19,
			wrong: 1,
			printed: 93
		}
	},
	{
		id: "qusqanat",
		category: "zoomorphic",
		name: {
			en: "Qusqanat",
			kk: "Құсқанат"
		},
		gloss: {
			en: "Bird’s wing",
			kk: "Құс қанаты"
		},
		form: {
			en: "A wing, built from horn-curves or from stepped feathers, as if a bird were coming in with wings open. It is usually mixed with other motifs rather than used alone.",
			kk: "Қанат. Мүйіз иірімінен не сатылы қауырсыннан құралады — құс қанатын жайып келе жатқандай. Көбіне жеке емес, басқа өрнекпен араласады."
		},
		meaning: {
			en: "Freedom, height, and a good wish. Popular teaching also calls it victory. The study treats it as a wish for liberty and for rising.",
			kk: "Еркіндік, биіктік және ізгі тілек. Көпшілік оқытуда жеңіс деп те аталады. Зерттеу оны бостандық пен өрлеу тілегі деп қарайды."
		},
		use: {
			en: "Felt, clothing, saddle cloths, usually beside a horn ornament.",
			kk: "Киіз, киім, ертұрман. Көбіне мүйіз өрнектің жанында."
		},
		symmetry: {
			en: "One-sided sweep",
			kk: "Бір жаққа серпілген"
		},
		visual: "an open bird wing of several curved feathers sweeping to one side",
		studied: true,
		control: {
			images: 20,
			correct: 18,
			wrong: 2,
			printed: 88
		}
	},
	{
		id: "qus-tumsyq",
		category: "zoomorphic",
		name: {
			en: "Qus tumsyq",
			kk: "Құстұмсық"
		},
		gloss: {
			en: "Bird’s beak",
			kk: "Құс тұмсығы"
		},
		form: {
			en: "A hooked beak, repeated in a row. Closely related to qus muryn, the bird’s nose.",
			kk: "Ілмек тұмсық, қатарлап қайталанады. Құсмұрынға жақын."
		},
		meaning: {
			en: "A wish to rise the way a bird does: freedom, and a fortunate life. It was placed on the clothes of young women and men, and on the goods of a new household.",
			kk: "Құстай самғау тілегі: еркіндік пен бақ. Жас қыз бен жігіт киіміне, жаңа отаудың жасауына салынған."
		},
		use: {
			en: "Clothing, bridal goods, the gaps in a spiral border.",
			kk: "Киім, жасау, шиыршық жиектің арасы."
		},
		symmetry: {
			en: "Repeating hook",
			kk: "Қайталанатын ілмек"
		},
		visual: "a row of hooked bird beaks"
	},
	{
		id: "aqqy-moin",
		category: "zoomorphic",
		name: {
			en: "Aqqy moin",
			kk: "Аққумойын"
		},
		gloss: {
			en: "Swan neck",
			kk: "Аққу мойны"
		},
		form: {
			en: "One long, smooth S. A swan’s neck, with no branches and no horn joint.",
			kk: "Бір ұзын, тегіс S. Аққудың мойны — тармақсыз, мүйіз буынынсыз."
		},
		meaning: {
			en: "Grace and tenderness.",
			kk: "Нәзіктік пен сұлулық."
		},
		use: {
			en: "Embroidery, clothing edges, decorative panels.",
			kk: "Кесте, киім жиегі, сәндік тақта."
		},
		symmetry: {
			en: "Single S-curve",
			kk: "Жалғыз S иірім"
		},
		visual: "one long smooth S-curve like a swan neck, unbranched"
	},
	{
		id: "orkesh",
		category: "zoomorphic",
		name: {
			en: "Orkesh",
			kk: "Өркеш"
		},
		gloss: {
			en: "Camel hump",
			kk: "Түйе өркеші"
		},
		form: {
			en: "One or two arches, the hump of a camel, often as a pair.",
			kk: "Бір не екі доға — түйенің өркеші, көбіне қос болып келеді."
		},
		meaning: {
			en: "Dignity, festivity, and wealth: the well-fed camel.",
			kk: "Асқақтық, салтанат және байлық — тойған түйе."
		},
		use: {
			en: "Felt and camel gear.",
			kk: "Киіз бұйым және түйе әбзелі."
		},
		symmetry: {
			en: "Paired arches",
			kk: "Қос доға"
		},
		visual: "one or two camel-hump arches"
	},
	{
		id: "bota-koz",
		category: "zoomorphic",
		name: {
			en: "Bota koz",
			kk: "Ботакөз"
		},
		gloss: {
			en: "Calf’s eye",
			kk: "Ботаның көзі"
		},
		form: {
			en: "An almond eye, the eye of a camel calf, sometimes with a spiral for the pupil. It is a guardian sign, not a portrait.",
			kk: "Бадам тәрізді көз — ботаның көзі, қарашығы кейде шиыршық. Бұл портрет емес, қорғау белгісі."
		},
		meaning: {
			en: "Protection from the evil eye.",
			kk: "Көз тиюден сақтау."
		},
		use: {
			en: "Clothing, jewelry, felt, and things made for children.",
			kk: "Киім, зергерлік, киіз және балаға арналған бұйым."
		},
		symmetry: {
			en: "Bilateral almond",
			kk: "Екі жақты бадам"
		},
		visual: "an almond-shaped eye with a marked pupil"
	},
	{
		id: "zhylan-iz",
		category: "zoomorphic",
		name: {
			en: "Zhylan izi",
			kk: "Жылан ізі"
		},
		gloss: {
			en: "Snake track",
			kk: "Жыланның ізі"
		},
		form: {
			en: "A running wave, the track a snake leaves. Not a horn and not the angular water-meander called irek.",
			kk: "Жүгіріп отыратын толқын — жылан қалдыратын із. Мүйіз емес және ирек судың сынық меандры да емес."
		},
		meaning: {
			en: "Caution and watchfulness.",
			kk: "Сақтық пен қырағылық."
		},
		use: {
			en: "Borders. Cutting guides also place it on trousers.",
			kk: "Жиек. Пішу нұсқаулығында шалбарға да салынады."
		},
		symmetry: {
			en: "Repeating wave",
			kk: "Қайталанатын толқын"
		},
		visual: "a smooth sine-wave snake track, not a spiral and not a Greek key"
	},
	{
		id: "tumarsha",
		category: "geometric",
		name: {
			en: "Tumarsha",
			kk: "Тұмарша"
		},
		gloss: {
			en: "Little amulet",
			kk: "Кішкене тұмар"
		},
		form: {
			en: "A triangle, the shape of a tumar amulet, often a triangle inside a triangle. Threes recur: three corners, sometimes three flowers.",
			kk: "Үшбұрыш — тұмардың пішіні, көбіне үшбұрыштың ішінде тағы үшбұрыш. Үш саны қайталанады: үш бұрыш, кейде үш гүл."
		},
		meaning: {
			en: "Apotropaic. It guards people and livestock against the evil eye and against harm. The study ties that protective sense to older totemic belief.",
			kk: "Апотропейлік, яғни қорғаушы. Адам мен малды тіл-көзден, жамандықтан сақтайды. Зерттеу бұл мағынаны ескі тотемдік сеніммен байланыстырады."
		},
		use: {
			en: "Worn as a real amulet on people and animals. As ornament: carpet borders, and the middle of felt and tekemet.",
			kk: "Адам мен малға нағыз бойтұмар ретінде тағылған. Өрнек ретінде: кілем жиегі, киіз бен текеметтің ортасы."
		},
		symmetry: {
			en: "Axial, triangular",
			kk: "Осьтік, үшбұрышты"
		},
		visual: "a triangle or a triangle inside a triangle, straight sides, an amulet shape",
		studied: true,
		control: {
			images: 20,
			correct: 18,
			wrong: 2,
			printed: 91
		}
	},
	{
		id: "tortqulaq",
		category: "geometric",
		name: {
			en: "Tortqulaq",
			kk: "Төртқұлақ"
		},
		gloss: {
			en: "Four ears",
			kk: "Төрт құлақ"
		},
		form: {
			en: "Four arms, like a cross. Each arm ends in a horn or a plant curl. The name means “four ears.”",
			kk: "Төрт тармақ, крест тәрізді. Әр тармақ мүйіз не өсімдік иірімімен бітеді. Атауы — «төрт құлақ»."
		},
		meaning: {
			en: "Steadiness and the four directions. Ethnographers also link it with earth and with a clan tamga: a totem animal reduced to a sign.",
			kk: "Орнықтылық және төрт бағыт. Зерттеушілер оны жермен және ру таңбасымен де байланыстырады: тотем аң белгіге жинақталған."
		},
		use: {
			en: "Central medallions of syrmak and tekemet, coats, felt.",
			kk: "Сырмақ пен текеметтің орталық дөңгелегі, шапан, киіз."
		},
		symmetry: {
			en: "Four-fold",
			kk: "Төрт жақты"
		},
		visual: "a cross or square with a horn-curl toward each of the four directions"
	},
	{
		id: "irek",
		category: "geometric",
		name: {
			en: "Irek",
			kk: "Ирек"
		},
		gloss: {
			en: "Running water",
			kk: "Ирек су"
		},
		form: {
			en: "A repeated zigzag or angular meander. Read as running water. The smooth snake track is a different motif.",
			kk: "Қайталанатын ирек не сынық меандр. Ағын су деп оқылады. Тегіс жылан ізі — басқа өрнек."
		},
		meaning: {
			en: "The current of life, and movement that does not stop.",
			kk: "Өмірдің ағысы және тоқтамайтын қозғалыс."
		},
		use: {
			en: "Borders. Cutting guides place irek su on trousers.",
			kk: "Жиек. Пішу нұсқаулығында ирек су шалбарға салынады."
		},
		symmetry: {
			en: "Running repeat",
			kk: "Жүгіріп қайталану"
		},
		visual: "an angular zigzag or Greek-key meander, water, not a smooth wave"
	},
	{
		id: "shytirman",
		category: "geometric",
		name: {
			en: "Shytirman",
			kk: "Шытырман"
		},
		gloss: {
			en: "Maze",
			kk: "Шытырман"
		},
		form: {
			en: "A maze or a square spiral with no quick way out.",
			kk: "Лабиринт не шаршы шиыршық — тез шығатын жолы жоқ."
		},
		meaning: {
			en: "Getting through a hard place. Persistence.",
			kk: "Қиындықтан өту. Табандылық."
		},
		use: {
			en: "Borders, felt, and, in popular placement, footwear.",
			kk: "Жиек, киіз, көпшілік орналастыруда аяқ киім."
		},
		symmetry: {
			en: "Spiral, centered",
			kk: "Орталық шиыршық"
		},
		visual: "a square maze or square spiral"
	},
	{
		id: "omyrqa",
		category: "geometric",
		name: {
			en: "Omyrtqa",
			kk: "Омыртқа"
		},
		gloss: {
			en: "Spine",
			kk: "Омыртқа"
		},
		form: {
			en: "A chain of vertebrae: diamonds or blocks linked like a backbone.",
			kk: "Омыртқалар тізбегі: ромб не буын арқа сүйегі сияқты жалғасқан."
		},
		meaning: {
			en: "Life and the living body. Continuity of the backbone.",
			kk: "Өмір мен тіршілік. Арқаның үзілмеуі."
		},
		use: {
			en: "Borders on felt, clothing, and mats.",
			kk: "Киіз, киім және шидің жиегі."
		},
		symmetry: {
			en: "Linear chain",
			kk: "Тізбекті"
		},
		visual: "a chain of linked diamonds like vertebrae"
	},
	{
		id: "sharshy",
		category: "geometric",
		name: {
			en: "Sharshy",
			kk: "Шаршы"
		},
		gloss: {
			en: "Square",
			kk: "Шаршы"
		},
		form: {
			en: "A square, sometimes stood on its point, sometimes nested. The right angle is what holds a composition still.",
			kk: "Шаршы, кейде бұрышымен тұрғызылған, кейде бірінің ішінде бірі. Тік бұрыш композицияны орнықты ұстайды."
		},
		meaning: {
			en: "Popular teaching says balance and fairness. As a form, it is the still frame around a wilder motif.",
			kk: "Мектепте үйлесім мен әділет деп оқылады. Пішін ретінде ол еркін өрнекті ұстап тұратын тыныш жақтау."
		},
		use: {
			en: "Coats, carpets, central fields.",
			kk: "Шапан, кілем, орталық алаң."
		},
		symmetry: {
			en: "Four-fold",
			kk: "Төрт жақты"
		},
		visual: "a square, nested squares, or a square on its point"
	},
	{
		id: "shynzhyr",
		category: "geometric",
		name: {
			en: "Shynzhyr",
			kk: "Шынжыр"
		},
		gloss: {
			en: "Chain",
			kk: "Шынжыр"
		},
		form: {
			en: "Interlocking links.",
			kk: "Бір-біріне кіріскен буындар."
		},
		meaning: {
			en: "Continuity from one generation to the next.",
			kk: "Ұрпақтан ұрпаққа жалғасу."
		},
		use: {
			en: "Borders of clothing and jewelry.",
			kk: "Киім жиегі мен зергерлік."
		},
		symmetry: {
			en: "Linear repeat",
			kk: "Тізбекті қайталау"
		},
		visual: "a chain of interlocking oval links"
	},
	{
		id: "gul",
		category: "plant",
		name: {
			en: "Gul",
			kk: "Гүл"
		},
		gloss: {
			en: "Flower",
			kk: "Гүл"
		},
		form: {
			en: "A rosette: petals around a center. It is not a drawing of a particular flower.",
			kk: "Розетка: ортаға жиналған күлте. Нақты бір гүлдің суреті емес."
		},
		meaning: {
			en: "Tenderness and beauty.",
			kk: "Нәзіктік пен сұлулық."
		},
		use: {
			en: "Embroidery, tuskiiz, jewelry, the middle of a panel.",
			kk: "Кесте, түскиіз, зергерлік, тақтаның ортасы."
		},
		symmetry: {
			en: "Radial",
			kk: "Шоғырлы"
		},
		visual: "a flower rosette with petals around a center"
	},
	{
		id: "zhapyraq",
		category: "plant",
		name: {
			en: "Zhapyraq",
			kk: "Жапырақ"
		},
		gloss: {
			en: "Leaf",
			kk: "Жапырақ"
		},
		form: {
			en: "One symmetric leaf with a midrib. A filler between larger horn motifs.",
			kk: "Орталық жүйкесі бар бір симметриялы жапырақ. Ірі мүйіз өрнектің арасын толтырады."
		},
		meaning: {
			en: "Youth and the growth of spring.",
			kk: "Жастық және көктемгі жаңару."
		},
		use: {
			en: "Embroidery and the spaces inside a border.",
			kk: "Кесте және жиектің ішкі бос жері."
		},
		symmetry: {
			en: "Bilateral",
			kk: "Екі жақты"
		},
		visual: "a single symmetric leaf with a central vein"
	},
	{
		id: "ush-zhapyraq",
		category: "plant",
		name: {
			en: "Ush zhapyraq",
			kk: "Үш жапырақ"
		},
		gloss: {
			en: "Three leaves",
			kk: "Үш жапырақ"
		},
		form: {
			en: "Three leaves from one point, a trefoil.",
			kk: "Бір нүктеден шыққан үш жапырақ, трилистник."
		},
		meaning: {
			en: "School teaching reads the three leaves as past, present, and future held together. That reading is pedagogical. The form is a trefoil.",
			kk: "Мектепте үш жапырақты өткен, бүгін және болашақтың бірлігі деп оқиды. Бұл — оқулықтық оқылым. Пішіні — үштік жапырақ."
		},
		use: {
			en: "Embroidery, small fills, jewelry.",
			kk: "Кесте, ұсақ толтыру, зергерлік."
		},
		symmetry: {
			en: "Three-fold",
			kk: "Үш жақты"
		},
		visual: "three leaves from one center, a trefoil"
	},
	{
		id: "agash",
		category: "plant",
		name: {
			en: "Agash",
			kk: "Ағаш"
		},
		gloss: {
			en: "Tree",
			kk: "Ағаш"
		},
		form: {
			en: "A trunk with curling branches. In Turkic ornament this sits near the world-tree idea, but on a textile it is a growth motif, not a landscape.",
			kk: "Бұтақтары иірілген дің. Түркі өрнегінде бұл әлем ағашына жақын, бірақ матада ол пейзаж емес, өсу белгісі."
		},
		meaning: {
			en: "Life, growth, and a line that continues upward.",
			kk: "Өмір, өсіп-өну және жоғары жалғасатын желі."
		},
		use: {
			en: "Central panels, embroidery, wood.",
			kk: "Орталық тақта, кесте, ағаш бұйым."
		},
		symmetry: {
			en: "Bilateral branches",
			kk: "Екі жақты бұтақ"
		},
		visual: "a stylized tree, a trunk with curling branches"
	},
	{
		id: "kun",
		category: "cosmogonic",
		name: {
			en: "Kun",
			kk: "Күн"
		},
		gloss: {
			en: "Sun",
			kk: "Күн"
		},
		form: {
			en: "A disk, sometimes with rays, a cross, or a swirl. Ethnographic notes also tie the circle to the face of a shaman’s drum.",
			kk: "Дөңгелек, кейде сәулелі, кресті не иірімді. Этнографиялық жазба дөңгелекті бақсы дабылының бетімен де байланыстырады."
		},
		meaning: {
			en: "Light, warmth, and power. Sky, sun, and the wider world.",
			kk: "Жарық, жылу және қуат. Аспан, күн және кең әлем."
		},
		use: {
			en: "Drums, jewelry, central medallions, the back of a coat, wood.",
			kk: "Дабыл, зергерлік, орталық дөңгелек, шапан арқасы, ағаш."
		},
		symmetry: {
			en: "Radial",
			kk: "Шоғырлы"
		},
		visual: "a sun disk with rays or a cross inside a circle"
	},
	{
		id: "ai",
		category: "cosmogonic",
		name: {
			en: "Ai",
			kk: "Ай"
		},
		gloss: {
			en: "Moon",
			kk: "Ай"
		},
		form: {
			en: "A crescent. Small repeated crescents are called ai-shyq and belong to embroidery.",
			kk: "Жарты ай. Ұсақ қайталанатын ай пішіндері айшық деп аталады, кестеде жүреді."
		},
		meaning: {
			en: "The moon: night, and a measured light. The crescent also appears in rites around a horse with a moon-like blaze.",
			kk: "Ай: түн және мөлшерлі жарық. Жарты ай қасқасы айға ұқсайтын жылқыға қатысты рәсімде де кездеседі."
		},
		use: {
			en: "Embroidery, jewelry, felt.",
			kk: "Кесте, зергерлік, киіз."
		},
		symmetry: {
			en: "Crescent",
			kk: "Жарты ай"
		},
		visual: "a crescent moon"
	},
	{
		id: "zhuldyz",
		category: "cosmogonic",
		name: {
			en: "Zhuldyz",
			kk: "Жұлдыз"
		},
		gloss: {
			en: "Star",
			kk: "Жұлдыз"
		},
		form: {
			en: "A star of four, five, six, or eight points. Eight is common in Central Asian ornament.",
			kk: "Төрт, бес, алты не сегіз қырлы жұлдыз. Орталық Азия өрнегінде сегіздік жиі."
		},
		meaning: {
			en: "Happiness and a high aim. Ethnographic notes also attach intellect and authority to the star.",
			kk: "Бақыт және биік мақсат. Этнографиялық жазба жұлдызға ақыл мен билікті де телиді."
		},
		use: {
			en: "Central medallions, jewelry, tuskiiz.",
			kk: "Орталық дөңгелек, зергерлік, түскиіз."
		},
		symmetry: {
			en: "Radial",
			kk: "Шоғырлы"
		},
		visual: "a star, often eight-pointed"
	}
];
function ornamentById(id) {
	if (!id) return void 0;
	return ORNAMENTS.find((item) => item.id === id);
}
var SOURCE_LINE = {
	en: "Grouped by Özbekali Janibekov’s four motifs: animal, plant, geometric, and cosmogonic (heavenly bodies), as used in the Qazaq Ornament study. Forms follow published Kazakh ornament descriptions. Where a meaning is mainly how the motif is taught in school, the text says so. Regional names differ.",
	kk: "Өзбекәлі Жәнібековтің төрт мотиві бойынша топталған: жануар, өсімдік, геометриялық және космогониялық (аспан денелері). Qazaq Ornament зерттеуі осы жіктеуді ұстанған. Пішіндер жарияланған қазақ ою сипаттамаларына сүйенеді. Мағына негізінен мектепте оқытылатын болса, мәтін соны айтады. Аймақтық атаулар әртүрлі."
};
//#endregion
export { ornamentById as i, ORNAMENTS as n, SOURCE_LINE as r, CATEGORIES as t };
