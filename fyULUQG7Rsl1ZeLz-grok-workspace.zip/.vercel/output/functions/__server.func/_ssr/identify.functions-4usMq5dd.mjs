import { n as ORNAMENTS } from "./ornaments-ClDQPi3C.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identify.functions-4usMq5dd.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var IDS = new Set(ORNAMENTS.map((item) => item.id));
function catalog() {
	return ORNAMENTS.map((item) => `${item.id}: ${item.visual}`).join("\n");
}
function clampConf(value) {
	let n = typeof value === "number" ? value : Number(value);
	if (!Number.isFinite(n)) return 0;
	if (n > 1) n = n / 100;
	return Math.min(1, Math.max(0, n));
}
function asId(value) {
	if (typeof value !== "string") return null;
	return IDS.has(value) ? value : null;
}
var identifyOrnament_createServerFn_handler = createServerRpc({
	id: "126c998eaa7adfe534cc92128efeee965818d99c3ed75cc9e68f416f83c8633f",
	name: "identifyOrnament",
	filename: "src/lib/identify.functions.ts"
}, (opts) => identifyOrnament.__executeServer(opts));
var identifyOrnament = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input.image !== "string") throw new Error("Image required");
	if (input.image.length > 28e5) throw new Error("Image too large");
	if (!/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(input.image)) throw new Error("Use a JPG, PNG, or WebP");
	const lang = input.lang === "kk" ? "kk" : "en";
	return {
		image: input.image,
		lang
	};
}).handler(identifyOrnament_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: data.lang === "kk" ? "Тану қызметі қазір қолжетімсіз." : "Recognition is not available right now."
	};
	const prompt = `You match a picture to a Kazakh ornament (oyu-örnek) using only visible geometry.
Pick one id from the catalog. If this is not an ornament, or no single motif dominates, set id to null.
If many motifs share the frame, choose the one that fills the center.
Do not discuss symbolism, history, or names beyond the id.
observation: one short sentence about the shape only, in ${data.lang === "kk" ? "Kazakh" : "English"}.

Catalog:
${catalog()}

Reply with JSON only:
{"id": string | null, "confidence": number from 0 to 1, "alternates": [{"id": string, "confidence": number}], "observation": string}`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(28e3),
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: 0,
				max_tokens: 350,
				messages: [{
					role: "system",
					content: "Reply with one JSON object and nothing else."
				}, {
					role: "user",
					content: [{
						type: "text",
						text: prompt
					}, {
						type: "image_url",
						image_url: { url: data.image }
					}]
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: data.lang === "kk" ? "Сурет оқылмады. Қайталап көріңіз немесе жинақтан салыстырыңыз." : "The picture could not be read. Try again, or compare it in the atlas."
		};
		const text = (await res.json()).choices?.[0]?.message?.content ?? "";
		const start = text.indexOf("{");
		const end = text.lastIndexOf("}");
		if (start < 0 || end < start) return {
			ok: false,
			error: data.lang === "kk" ? "Жауап түсініксіз болды." : "The answer was not usable."
		};
		const raw = JSON.parse(text.slice(start, end + 1));
		const alternates = Array.isArray(raw.alternates) ? raw.alternates.map((item) => ({
			id: asId(item.id),
			confidence: clampConf(item.confidence)
		})).filter((item) => item.id !== null).filter((item) => item.id !== asId(raw.id)).slice(0, 2) : [];
		return {
			ok: true,
			id: asId(raw.id),
			confidence: clampConf(raw.confidence),
			alternates,
			observation: typeof raw.observation === "string" ? raw.observation.slice(0, 280) : ""
		};
	} catch {
		return {
			ok: false,
			error: data.lang === "kk" ? "Тану уақыты бітті немесе үзілді. Тағы бір рет көріңіз." : "Recognition timed out or stopped. Try once more."
		};
	}
});
//#endregion
export { identifyOrnament_createServerFn_handler };
