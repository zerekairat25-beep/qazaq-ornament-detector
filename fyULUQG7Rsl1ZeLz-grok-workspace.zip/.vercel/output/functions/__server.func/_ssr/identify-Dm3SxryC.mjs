import { i as __toESM } from "../_runtime.mjs";
import { i as ornamentById, n as ORNAMENTS, t as CATEGORIES } from "./ornaments-ClDQPi3C.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useI18n } from "./router-CJZuxMDe.mjs";
import { a as Shell, i as OrnamentMark, t as Btn } from "./shell-CaHBhDP-.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/identify-Dm3SxryC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var identifyOrnament = createServerFn({ method: "POST" }).validator((input) => {
	if (!input || typeof input.image !== "string") throw new Error("Image required");
	if (input.image.length > 28e5) throw new Error("Image too large");
	if (!/^data:image\/(jpeg|jpg|png|webp);base64,/i.test(input.image)) throw new Error("Use a JPG, PNG, or WebP");
	const lang = input.lang === "kk" ? "kk" : "en";
	return {
		image: input.image,
		lang
	};
}).handler(createSsrRpc("126c998eaa7adfe534cc92128efeee965818d99c3ed75cc9e68f416f83c8633f"));
function IdentifyPage() {
	const { t, lang } = useI18n();
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	async function onFile(file) {
		if (!file) return;
		if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
			setError(t({
				en: "Use a JPG, PNG, or WebP.",
				kk: "JPG, PNG не WebP жүктеңіз."
			}));
			return;
		}
		setError(null);
		setResult(null);
		setBusy(true);
		try {
			const image = await shrink(file);
			setPreview(image);
			const response = await identifyOrnament({ data: {
				image,
				lang
			} });
			if (!response.ok) {
				setError(response.error);
				return;
			}
			setResult(response);
		} catch (err) {
			setError(err instanceof Error ? err.message : t({
				en: "Could not read that file.",
				kk: "Файл оқылмады."
			}));
		} finally {
			setBusy(false);
		}
	}
	result && ornamentById(result.id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[1fr_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-accent uppercase",
				children: t({
					en: "Recognition desk",
					kk: "Тану үстелі"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl",
				children: t({
					en: "Ask a picture",
					kk: "Суреттен сұраңыз"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: t({
					en: "The photo is matched to this catalog by shape. The meaning you then see is the catalog’s, not a free explanation. The study’s own ResNet or MobileNet weights are not running here. Similar horns were the hard cases in the control test.",
					kk: "Сурет пішіні бойынша осы жинаққа сәйкеседі. Кейін көретін мағына жинақтікі, еркін түсіндірме емес. Зерттеудегі ResNet не MobileNet салмақтары мұнда жұмыс істемейді. Бақылауда ең қиыны ұқсас мүйіздер болған."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-6 flex min-h-52 cursor-pointer flex-col items-center justify-center border border-dashed border-accent bg-surface px-4 py-8 text-center",
				onDragOver: (event) => event.preventDefault(),
				onDrop: (event) => {
					event.preventDefault();
					onFile(event.dataTransfer.files[0]);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/jpeg,image/png,image/webp",
					className: "sr-only",
					onChange: (event) => void onFile(event.target.files?.[0])
				}), preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: preview,
					alt: "",
					className: "max-h-48 object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
						id: "qoshqar-muyiz",
						className: "size-16 text-accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-medium",
						children: t({
							en: "Drop a photo, or choose one",
							kk: "Суретті тастаңыз не таңдаңыз"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: t({
							en: "A single motif, filling the frame, works better than a whole carpet.",
							kk: "Тұтас кілемнен гөрі кадрды толтырған бір өрнек дәлірек."
						})
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					disabled: busy,
					onClick: () => document.querySelector("input[type=\"file\"]")?.click(),
					children: busy ? t({
						en: "Reading the picture…",
						kk: "Сурет оқылып жатыр…"
					}) : t({
						en: "Choose a photo",
						kk: "Сурет таңдау"
					})
				})
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-primary",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 space-y-3 text-sm text-muted",
				children: [
					{
						en: "The picture is sent once, when you ask.",
						kk: "Сурет сіз сұрағанда бір рет жіберіледі."
					},
					{
						en: "It is scaled down, then classed against the catalog.",
						kk: "Ол кішірейтіледі, сосын жинақпен салыстырылады."
					},
					{
						en: "The class opens the fixed card: name, meaning, place.",
						kk: "Класс бекітілген карточканы ашады: атау, мағына, орын."
					}
				].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl text-accent",
						children: index + 1
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pt-1",
						children: t(step)
					})]
				}, step.en))
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border border-line bg-surface p-5",
			children: !result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: t({
						en: "Five classes from the test",
						kk: "Сынақтағы бес класс"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: t({
						en: "These are the motifs the study measured. Open one in the atlas while you wait.",
						kk: "Зерттеу өлшеген өрнектер осылар. Күтіп тұрғанда жинақтан ашыңыз."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 grid grid-cols-2 gap-3",
					children: ORNAMENTS.filter((item) => item.studied).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
								id: item.id,
								className: "size-16",
								title: t(item.name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-xl",
								children: t(item.name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: item.control ? `${item.control.correct}/${item.control.images}` : ""
							})
						]
					}, item.id))
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Result, { result })
		})]
	}) });
}
function Result({ result }) {
	const { t } = useI18n();
	const ornament = ornamentById(result.id);
	const pct = Math.round(result.confidence * 100);
	if (!ornament) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t({
				en: "No single motif dominated",
				kk: "Бір өрнек басым болмады"
			})
		}),
		result.observation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm leading-relaxed",
			children: result.observation
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: t({
				en: "Crop closer to one motif, or look through the atlas. A whole carpet is a crowd of signs.",
				kk: "Бір өрнекке жақындатып қиыңыз не жинақты қараңыз. Тұтас кілем — белгілердің жиыны."
			})
		})
	] });
	const category = CATEGORIES.find((item) => item.id === ornament.category);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs font-semibold tracking-wide text-accent uppercase",
			children: [
				t(category.label),
				" · ",
				pct,
				"%"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 h-1.5 bg-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full bg-primary",
				style: { width: `${pct}%` }
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
				id: ornament.id,
				className: "size-24",
				title: t(ornament.name)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl",
				children: t(ornament.name)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: t(ornament.gloss)
			})] })]
		}),
		result.observation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm leading-relaxed",
			children: result.observation
		}) : null,
		pct < 45 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-primary",
			children: t({
				en: "Low confidence. Horn motifs were easy to mix up in the study too. Compare the atlas.",
				kk: "Сенім төмен. Зерттеуде де мүйіз өрнектер шатасқан. Жинақпен салыстырыңыз."
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-5 font-display text-2xl",
			children: t({
				en: "Meaning",
				kk: "Мағынасы"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed",
			children: t(ornament.meaning)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-5 font-display text-2xl",
			children: t({
				en: "Form",
				kk: "Пішіні"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed",
			children: t(ornament.form)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-5 font-display text-2xl",
			children: t({
				en: "Where it sits",
				kk: "Қайда тұрады"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed",
			children: t(ornament.use)
		}),
		result.alternates.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-muted uppercase",
				children: t({
					en: "Also considered",
					kk: "Тағы қаралғаны"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-wrap gap-2",
				children: result.alternates.map((alt) => {
					const other = ornamentById(alt.id);
					if (!other) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line px-3 py-2 text-sm",
						children: [
							t(other.name),
							" · ",
							Math.round(alt.confidence * 100),
							"%"
						]
					}, alt.id);
				})
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				href: "/atlas",
				tone: "quiet",
				children: t({
					en: "See it in the atlas",
					kk: "Жинақтан көру"
				})
			})
		})
	] });
}
async function shrink(file) {
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, 768 / Math.max(bitmap.width, bitmap.height));
	const width = Math.max(1, Math.round(bitmap.width * scale));
	const height = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not prepare the picture");
	ctx.drawImage(bitmap, 0, 0, width, height);
	bitmap.close();
	return canvas.toDataURL("image/jpeg", .82);
}
//#endregion
export { IdentifyPage as component };
