import { i as __toESM } from "../_runtime.mjs";
import { n as ORNAMENTS, r as SOURCE_LINE, t as CATEGORIES } from "./ornaments-ClDQPi3C.mjs";
import { S as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route$3, r as useI18n } from "./router-CJZuxMDe.mjs";
import { a as Shell, i as OrnamentMark, o as cn } from "./shell-CaHBhDP-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/atlas-BxPCWNTT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AtlasPage() {
	const { cat } = Route$3.useSearch();
	const { t } = useI18n();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)(cat ?? "all");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (cat) setFilter(cat);
	}, [cat]);
	(0, import_react.useEffect)(() => {
		const hash = window.location.hash.replace("#", "");
		if (hash && ORNAMENTS.some((item) => item.id === hash)) setOpenId(hash);
	}, []);
	const list = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return ORNAMENTS.filter((item) => {
			if (filter !== "all" && item.category !== filter) return false;
			if (!q) return true;
			return [
				item.name.en,
				item.name.kk,
				item.gloss.en,
				item.gloss.kk,
				item.meaning.en,
				item.meaning.kk
			].join(" ").toLowerCase().includes(q);
		});
	}, [filter, query]);
	const open = ORNAMENTS.find((item) => item.id === openId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-widest text-accent uppercase",
				children: t({
					en: "The record",
					kk: "Дерек"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl md:text-6xl",
				children: t({
					en: "Ornament atlas",
					kk: "Ою жинағы"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-2xl text-muted",
				children: t(SOURCE_LINE)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 md:flex-row md:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "sr-only",
						htmlFor: "ornament-search",
						children: t({
							en: "Search ornaments",
							kk: "Ою іздеу"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "ornament-search",
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: t({
							en: "Search a name or a meaning",
							kk: "Атау не мағына іздеу"
						}),
						className: "min-h-11 w-full border border-line bg-surface px-3 text-sm md:max-w-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: filter === "all",
							onClick: () => setFilter("all"),
							children: t({
								en: "All",
								kk: "Бәрі"
							})
						}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
							active: filter === item.id,
							onClick: () => setFilter(item.id),
							children: t(item.label)
						}, item.id))]
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
				ornament: open,
				onClose: () => setOpenId(null)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid grid-cols-2 gap-3 md:grid-cols-3",
				children: list.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					id: item.id,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setOpenId(item.id);
							document.getElementById("ornament-detail")?.scrollIntoView({ block: "nearest" });
						},
						className: cn("flex h-full w-full flex-col border bg-surface p-4 text-left transition-transform duration-150 ease-out active:scale-[0.98]", openId === item.id ? "border-primary" : "border-line"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
								id: item.id,
								className: "size-24",
								title: t(item.name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-3 font-display text-2xl",
								children: t(item.name)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: t(item.gloss)
							}),
							item.studied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-3 text-xs font-semibold tracking-wide text-primary uppercase",
								children: t({
									en: "In the control test",
									kk: "Бақылау сынағында"
								})
							}) : null
						]
					})
				}, item.id))
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: t({
					en: "Nothing matches that search.",
					kk: "Іздеуге сай өрнек жоқ."
				})
			}) : null
		]
	}) });
}
function FilterChip({ active, children, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("min-h-11 px-3 text-sm font-medium", active ? "bg-fg text-bg" : "border border-line bg-surface text-fg"),
		children
	});
}
function Detail({ ornament, onClose }) {
	const { t } = useI18n();
	const category = CATEGORIES.find((item) => item.id === ornament.category);
	const rows = [
		{
			label: {
				en: "Name",
				kk: "Ою атауы"
			},
			value: ornament.name
		},
		{
			label: {
				en: "Category",
				kk: "Категориясы"
			},
			value: category.label
		},
		{
			label: {
				en: "Graphic form",
				kk: "Графикалық пішіні"
			},
			value: ornament.form
		},
		{
			label: {
				en: "Symmetry",
				kk: "Симметрия типі"
			},
			value: ornament.symmetry
		},
		{
			label: {
				en: "Meaning",
				kk: "Семантикалық мәні"
			},
			value: ornament.meaning
		},
		{
			label: {
				en: "Where it sits",
				kk: "Қолданылу контексті"
			},
			value: ornament.use
		},
		{
			label: {
				en: "Source frame",
				kk: "Дереккөз негізі"
			},
			value: {
				en: "Janibekov’s four-part classification, as used in the study. Forms from published Kazakh ornament descriptions.",
				kk: "Зерттеу ұстанған Жәнібековтің төрттік жіктеуі. Пішіндер жарияланған қазақ ою сипаттамаларынан."
			}
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		id: "ornament-detail",
		className: "mt-6 border border-line bg-surface p-5 md:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-accent uppercase",
					children: t(ornament.gloss)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl",
					children: t(ornament.name)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "min-h-11 px-3 text-sm text-muted",
					children: t({
						en: "Close",
						kk: "Жабу"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-6 md:grid-cols-[180px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-center border border-line bg-bg p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
						id: ornament.id,
						className: "size-36",
						title: t(ornament.name)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
					className: "divide-y divide-line",
					children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1 py-3 md:grid-cols-[160px_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs font-semibold tracking-wide text-accent uppercase",
							children: t(row.label)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-sm leading-relaxed",
							children: t(row.value)
						})]
					}, row.label.en))
				})]
			}),
			ornament.control ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: t({
					en: `Control test: ${ornament.control.correct} of ${ornament.control.images} images named correctly. The study text prints ${ornament.control.printed}%.`,
					kk: `Бақылау сынағы: ${ornament.control.images} суреттің ${ornament.control.correct}-і дұрыс аталды. Зерттеу мәтінінде ${ornament.control.printed}% деп жазылған.`
				})
			}) : null
		]
	});
}
//#endregion
export { AtlasPage as component };
