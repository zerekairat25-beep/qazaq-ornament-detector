import { i as __toESM } from "../_runtime.mjs";
import { S as require_jsx_runtime, Y as require_react, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as useI18n } from "./router-CJZuxMDe.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-CaHBhDP-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Ink({ children, width = 4.2 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
		fill: "none",
		stroke: "currentColor",
		strokeWidth: width,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		children
	});
}
function Qoshqar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 6,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M46 70 C32 70 18 58 22 42 C26 26 46 24 48 42 C50 54 38 56 34 46" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M54 70 C68 70 82 58 78 42 C74 26 54 24 52 42 C50 54 62 56 66 46" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M43 74 Q50 84 57 74" })
		]
	});
}
function Synar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ink, {
		width: 6,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M68 78 C42 80 18 64 22 42 C26 20 52 14 60 36 C68 56 46 62 40 48 C36 38 50 32 56 44" })
	});
}
function Qos() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 5.5,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M30 72 C18 72 8 58 12 44 C16 30 32 28 34 42 C36 52 26 54 22 46" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M70 72 C82 72 92 58 88 44 C84 30 68 28 66 42 C64 52 74 54 78 46" })]
	});
}
function Arqar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 4.5,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M46 76 C28 76 10 60 16 40 C22 18 46 10 52 32 C58 52 38 60 30 46 C24 36 38 28 46 40 C50 46 44 50 40 44" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M54 76 C72 76 90 60 84 40 C78 18 54 10 48 32 C42 52 62 60 70 46 C76 36 62 28 54 40 C50 46 56 50 60 44" })]
	});
}
function Qyryq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 3,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "50",
			cy: "50",
			r: "7"
		}), Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M0 2 C8 2 12 -8 4 -12 C-4 -16 -10 -6 -4 -2",
			transform: `translate(50 50) rotate(${i * 45}) translate(0 -24)`
		}, i))]
	});
}
function Synyq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M78 74 L62 74 L62 56 L46 56 L46 40 L30 40 L30 24 L18 24" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M22 70 L38 70 L38 52 L54 52 L54 36 L70 36" })] });
}
function Maral() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 84 V46" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 62 C38 58 30 46 34 34 C36 28 28 24 26 18" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 62 C62 58 70 46 66 34 C64 28 72 24 74 18" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 50 C40 40 36 30 28 28" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 50 C60 40 64 30 72 28" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M34 34 C40 26 36 18 42 16" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M66 34 C60 26 64 18 58 16" })
	] });
}
function Tuyetaban() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M42 16 C24 24 22 46 40 52 C52 56 24 64 32 86" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M58 16 C76 24 78 46 60 52 C48 56 76 64 68 86" })] });
}
function Qusqanat() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 4.5,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 78 C40 62 62 36 88 16" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M20 86 C46 68 70 50 92 38" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M28 92 C52 78 74 64 94 56" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 78 C10 66 22 62 26 72" })
		]
	});
}
function QusTumsyq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 64 C28 40 38 36 36 54" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M40 64 C52 40 62 36 60 54" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M64 64 C76 40 86 36 84 54" })
	] });
}
function Aqqy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ink, {
		width: 4.6,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M28 82 C26 52 58 50 52 28 C48 14 66 12 72 26 C78 40 62 44 64 30" })
	});
}
function Orkesh() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 4.6,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M10 72 Q30 26 50 72 Q70 26 90 72" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14 78 H86" })]
	});
}
function BotaKoz() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M14 50 Q50 18 86 50 Q50 82 14 50 Z",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "4.2"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M50 50 m-8 0 a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "3.4"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "50",
			cy: "50",
			r: "2.5",
			fill: "currentColor"
		})
	] });
}
function Zhylan() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 58 C18 36 28 74 40 54 C52 34 62 74 74 52 C82 40 88 36 92 28" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M88 22 L96 30 L86 32" })] });
}
function Tumarsha() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		fill: "currentColor",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fillRule: "evenodd",
			d: "M50 12 L88 84 L12 84 Z M50 34 L72 76 L28 76 Z"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 48 L62 74 L38 74 Z" })]
	});
}
function Tortqulaq() {
	const hook = "M0 0 C0 -18 -16 -24 -20 -12 C-24 -2 -12 2 -8 -8";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, {
		width: 4.2,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "38",
				y: "38",
				width: "24",
				height: "24"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: hook,
				transform: "translate(50 38) rotate(-90)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: hook,
				transform: "translate(62 50)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: hook,
				transform: "translate(50 62) rotate(90)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: hook,
				transform: "translate(38 50) rotate(180)"
			})
		]
	});
}
function Irek() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ink, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6 62 H22 V34 H38 V62 H54 V34 H70 V62 H86 V34 H96" }) });
}
function Shytirman() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ink, {
		width: 3.6,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 50 H66 V34 H30 V70 H78 V22 H18 V82 H86" })
	});
}
function Omyrtqa() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 50 L32 36 L46 50 L32 64 Z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M46 50 L60 34 L74 50 L60 66 Z" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 50 H18" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M74 50 H92" })
	] });
}
function Sharshy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "22",
			y: "22",
			width: "56",
			height: "56"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "34",
			y: "34",
			width: "32",
			height: "32"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 22 V34 M50 66 V78 M22 50 H34 M66 50 H78" })
	] });
}
function Shynzhyr() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
			cx: "24",
			cy: "50",
			rx: "14",
			ry: "18"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
			cx: "50",
			cy: "50",
			rx: "14",
			ry: "18"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
			cx: "76",
			cy: "50",
			rx: "14",
			ry: "18"
		})
	] });
}
function Gul() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		fill: "currentColor",
		children: [
			Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "50",
				cy: "24",
				rx: "7",
				ry: "16",
				transform: `rotate(${i * 45} 50 50)`
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "50",
				cy: "50",
				r: "7",
				fill: "var(--color-bg)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "50",
				cy: "50",
				r: "3.5"
			})
		]
	});
}
function Zhapyraq() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 86 C50 86 16 62 26 36 C34 16 50 12 50 12 C50 12 66 16 74 36 C84 62 50 86 50 86" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 78 V22" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 60 C38 54 32 46 30 38" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 60 C62 54 68 46 70 38" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 44 C40 40 36 34 36 28" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 44 C60 40 64 34 64 28" })
	] });
}
function UshZhapyraq() {
	const leaf = "M0 0 C-14 -6 -16 -28 0 -40 C16 -28 14 -6 0 0";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: leaf,
			transform: "translate(50 58)"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: leaf,
			transform: "translate(50 50) rotate(120)"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: leaf,
			transform: "translate(50 50) rotate(240)"
		})
	] });
}
function Agash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 88 V40" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 70 C32 66 22 52 28 40 C32 32 24 28 22 20" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 70 C68 66 78 52 72 40 C68 32 76 28 78 20" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 56 C36 44 34 30 24 26" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 56 C64 44 66 30 76 26" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 42 C42 30 44 18 50 12 C56 18 58 30 50 42" })
	] });
}
function Kun() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Ink, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "50",
			cy: "50",
			r: "14"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 36 V28 M50 64 V72 M36 50 H28 M64 50 H72" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M40 40 L34 34 M60 40 L66 34 M40 60 L34 66 M60 60 L66 66" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M50 44 V56 M44 50 H56" })
	] });
}
function Ai() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		fill: "currentColor",
		fillRule: "evenodd",
		d: "M48 16 A34 34 0 1 0 48 84 A34 34 0 1 0 48 16 Z M64 22 A26 26 0 1 0 64 78 A26 26 0 1 0 64 22 Z"
	});
}
var STAR = "M50 10 L56.1 35.2 L78.3 21.7 L64.8 43.9 L90 50 L64.8 56.1 L78.3 78.3 L56.1 64.8 L50 90 L43.9 64.8 L21.7 78.3 L35.2 56.1 L10 50 L35.2 43.9 L21.7 21.7 L43.9 35.2 Z";
function Zhuldyz() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
		d: STAR,
		fill: "currentColor"
	});
}
var MARKS = {
	"qoshqar-muyiz": Qoshqar,
	"synar-muyiz": Synar,
	"qos-muyiz": Qos,
	"arqar-muyiz": Arqar,
	"qyryq-muyiz": Qyryq,
	"synyq-muyiz": Synyq,
	"maral-muyiz": Maral,
	tuyetaban: Tuyetaban,
	qusqanat: Qusqanat,
	"qus-tumsyq": QusTumsyq,
	"aqqy-moin": Aqqy,
	orkesh: Orkesh,
	"bota-koz": BotaKoz,
	"zhylan-iz": Zhylan,
	tumarsha: Tumarsha,
	tortqulaq: Tortqulaq,
	irek: Irek,
	shytirman: Shytirman,
	omyrqa: Omyrtqa,
	sharshy: Sharshy,
	shynzhyr: Shynzhyr,
	gul: Gul,
	zhapyraq: Zhapyraq,
	"ush-zhapyraq": UshZhapyraq,
	agash: Agash,
	kun: Kun,
	ai: Ai,
	zhuldyz: Zhuldyz
};
function OrnamentMark({ id, className, title }) {
	const Mark = MARKS[id] ?? Qoshqar;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 100 100",
		className: cn("text-primary", className),
		role: title ? "img" : "presentation",
		"aria-label": title || void 0,
		"aria-hidden": title ? void 0 : true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {})
	});
}
function Medallion({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 200 200",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "100",
				cy: "100",
				r: "96",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "100",
				cy: "100",
				r: "88",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "100",
				cy: "100",
				r: "78",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
				transform: "translate(50 50)",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tortqulaq, {})
			})
		]
	});
}
function Frieze({ className }) {
	const id = (0, import_react.useId)().replace(/:/g, "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 360 28",
		className: cn("text-accent", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
			id,
			width: "48",
			height: "28",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M0 18 H12 V8 H24 V18 H36 V8 H48",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			})
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "360",
			height: "28",
			fill: `url(#${id})`
		})]
	});
}
var NAV = [
	{
		href: "/atlas",
		label: {
			en: "Atlas",
			kk: "Жинақ"
		}
	},
	{
		href: "/identify",
		label: {
			en: "Identify",
			kk: "Тану"
		}
	},
	{
		href: "/research",
		label: {
			en: "Study",
			kk: "Зерттеу"
		}
	},
	{
		href: "/learn",
		label: {
			en: "Learn",
			kk: "Үйрену"
		}
	}
];
function Shell({ children }) {
	const { t, lang, setLang } = useI18n();
	const path = useRouterState({ select: (state) => state.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrnamentMark, {
								id: "qoshqar-muyiz",
								className: "size-9 text-primary",
								title: "Qoshqar muyiz"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl leading-none text-fg",
								children: "Qazaq Ornament"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-1 flex-wrap items-center gap-1",
							children: NAV.map((item) => {
								const active = path === item.href;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: item.href,
									className: cn("inline-flex min-h-11 items-center px-3 text-sm font-medium", active ? "text-primary" : "text-muted hover:text-fg"),
									children: t(item.label)
								}, item.href);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex rounded-full border border-line bg-surface p-1",
							children: [["kk", "ҚАЗ"], ["en", "EN"]].map(([code, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setLang(code),
								className: cn("min-h-9 min-w-11 rounded-full px-3 text-xs font-semibold tracking-wide transition-colors", lang === code ? "bg-fg text-bg" : "text-muted"),
								"aria-pressed": lang === code,
								children: label
							}, code))
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-sm text-muted md:flex-row md:items-end md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl",
						children: t({
							en: "Meanings follow Janibekov’s four groups and published Kazakh ornament descriptions. Regional names differ. School readings are marked as such.",
							kk: "Мағыналар Жәнібековтің төрт тобына және жарияланған қазақ ою сипаттамаларына сүйенеді. Аймақтық атаулар әртүрлі. Мектептік оқылым солай деп белгіленген."
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl text-fg",
						children: "Qazaq Ornament"
					})]
				})
			})
		]
	});
}
function Btn({ href, children, tone = "primary", onClick, type = "button", disabled }) {
	const className = cn("inline-flex min-h-11 items-center justify-center px-5 text-sm font-semibold transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]", tone === "primary" && "bg-primary text-primary-fg", tone === "quiet" && "border border-line bg-surface text-fg", tone === "ghost" && "text-fg underline decoration-line underline-offset-4", disabled && "opacity-60");
	if (href) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: href,
		className,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		onClick,
		disabled,
		className,
		children
	});
}
//#endregion
export { Shell as a, OrnamentMark as i, Frieze as n, cn as o, Medallion as r, Btn as t };
