//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DJMoeHcV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/atlas",
			"/identify",
			"/learn",
			"/research"
		],
		preloads: ["/assets/index-DdATJiFq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DdATJiFq.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BldWWTkd.js", "/assets/ornaments-D3c-ox3L.js"]
	},
	"/atlas": {
		filePath: "/workspace/src/routes/atlas.tsx",
		children: void 0,
		preloads: ["/assets/atlas-BaDbD7LV.js", "/assets/ornaments-D3c-ox3L.js"]
	},
	"/identify": {
		filePath: "/workspace/src/routes/identify.tsx",
		children: void 0,
		preloads: ["/assets/identify-BEMNz_SY.js", "/assets/ornaments-D3c-ox3L.js"]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: void 0,
		preloads: ["/assets/learn-CHQbBTlo.js", "/assets/ornaments-D3c-ox3L.js"]
	},
	"/research": {
		filePath: "/workspace/src/routes/research.tsx",
		children: void 0,
		preloads: ["/assets/research-Drz889Qy.js", "/assets/ornaments-D3c-ox3L.js"]
	}
} });
//#endregion
export { tsrStartManifest };
