import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";
import { useI18n, type Bi } from "@/lib/i18n";
import { OrnamentMark } from "@/components/ornament-mark";

const NAV: { href: string; label: Bi }[] = [
  { href: "/atlas", label: { en: "Atlas", kk: "Жинақ" } },
  { href: "/identify", label: { en: "Identify", kk: "Тану" } },
  { href: "/research", label: { en: "Study", kk: "Зерттеу" } },
  { href: "/learn", label: { en: "Learn", kk: "Үйрену" } },
];

export function Shell({ children }: { children: ReactNode }) {
  const { t, lang, setLang } = useI18n();
  const path = useRouterState({ select: (state) => state.location.pathname });

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
          <Link to="/" className="flex items-center gap-2">
            <OrnamentMark id="qoshqar-muyiz" className="size-9 text-primary" title="Qoshqar muyiz" />
            <span className="font-display text-2xl leading-none text-fg">Qazaq Ornament</span>
          </Link>
          <nav className="flex flex-1 flex-wrap items-center gap-1">
            {NAV.map((item) => {
              const active = path === item.href;
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "inline-flex min-h-11 items-center px-3 text-sm font-medium",
                    active ? "text-primary" : "text-muted hover:text-fg",
                  )}
                >
                  {t(item.label)}
                </Link>
              );
            })}
          </nav>
          <div className="flex rounded-full border border-line bg-surface p-1">
            {(
              [
                ["kk", "ҚАЗ"],
                ["en", "EN"],
              ] as const
            ).map(([code, label]) => (
              <button
                key={code}
                type="button"
                onClick={() => setLang(code)}
                className={cn(
                  "min-h-9 min-w-11 rounded-full px-3 text-xs font-semibold tracking-wide transition-colors",
                  lang === code ? "bg-fg text-bg" : "text-muted",
                )}
                aria-pressed={lang === code}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </header>
      <main>{children}</main>
      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-8 text-sm text-muted md:flex-row md:items-end md:justify-between">
          <p className="max-w-xl">
            {t({
              en: "Meanings follow Janibekov’s four groups and published Kazakh ornament descriptions. Regional names differ. School readings are marked as such.",
              kk: "Мағыналар Жәнібековтің төрт тобына және жарияланған қазақ ою сипаттамаларына сүйенеді. Аймақтық атаулар әртүрлі. Мектептік оқылым солай деп белгіленген.",
            })}
          </p>
          <p className="font-display text-xl text-fg">Qazaq Ornament</p>
        </div>
      </footer>
    </div>
  );
}

export function Btn({
  href,
  children,
  tone = "primary",
  onClick,
  type = "button",
  disabled,
}: {
  href?: string;
  children: ReactNode;
  tone?: "primary" | "quiet" | "ghost";
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  const className = cn(
    "inline-flex min-h-11 items-center justify-center px-5 text-sm font-semibold transition-transform duration-150 ease-out active:not-disabled:scale-[0.96]",
    tone === "primary" && "bg-primary text-primary-fg",
    tone === "quiet" && "border border-line bg-surface text-fg",
    tone === "ghost" && "text-fg underline decoration-line underline-offset-4",
    disabled && "opacity-60",
  );
  if (href) {
    return (
      <Link to={href} className={className}>
        {children}
      </Link>
    );
  }
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={className}>
      {children}
    </button>
  );
}
