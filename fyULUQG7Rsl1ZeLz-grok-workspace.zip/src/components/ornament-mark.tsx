import { useId, type ReactNode } from "react";
import { cn } from "@/lib/cn";

function Ink({ children, width = 4.2 }: { children: ReactNode; width?: number }) {
  return (
    <g fill="none" stroke="currentColor" strokeWidth={width} strokeLinecap="round" strokeLinejoin="round">
      {children}
    </g>
  );
}

function Qoshqar() {
  return (
    <Ink width={6}>
      <path d="M46 70 C32 70 18 58 22 42 C26 26 46 24 48 42 C50 54 38 56 34 46" />
      <path d="M54 70 C68 70 82 58 78 42 C74 26 54 24 52 42 C50 54 62 56 66 46" />
      <path d="M43 74 Q50 84 57 74" />
    </Ink>
  );
}

function Synar() {
  return (
    <Ink width={6}>
      <path d="M68 78 C42 80 18 64 22 42 C26 20 52 14 60 36 C68 56 46 62 40 48 C36 38 50 32 56 44" />
    </Ink>
  );
}

function Qos() {
  return (
    <Ink width={5.5}>
      <path d="M30 72 C18 72 8 58 12 44 C16 30 32 28 34 42 C36 52 26 54 22 46" />
      <path d="M70 72 C82 72 92 58 88 44 C84 30 68 28 66 42 C64 52 74 54 78 46" />
    </Ink>
  );
}

function Arqar() {
  return (
    <Ink width={4.5}>
      <path d="M46 76 C28 76 10 60 16 40 C22 18 46 10 52 32 C58 52 38 60 30 46 C24 36 38 28 46 40 C50 46 44 50 40 44" />
      <path d="M54 76 C72 76 90 60 84 40 C78 18 54 10 48 32 C42 52 62 60 70 46 C76 36 62 28 54 40 C50 46 56 50 60 44" />
    </Ink>
  );
}

function Qyryq() {
  return (
    <Ink width={3}>
      <circle cx="50" cy="50" r="7" />
      {Array.from({ length: 8 }, (_, i) => (
        <path
          key={i}
          d="M0 2 C8 2 12 -8 4 -12 C-4 -16 -10 -6 -4 -2"
          transform={`translate(50 50) rotate(${i * 45}) translate(0 -24)`}
        />
      ))}
    </Ink>
  );
}

function Synyq() {
  return (
    <Ink>
      <path d="M78 74 L62 74 L62 56 L46 56 L46 40 L30 40 L30 24 L18 24" />
      <path d="M22 70 L38 70 L38 52 L54 52 L54 36 L70 36" />
    </Ink>
  );
}

function Maral() {
  return (
    <Ink>
      <path d="M50 84 V46" />
      <path d="M50 62 C38 58 30 46 34 34 C36 28 28 24 26 18" />
      <path d="M50 62 C62 58 70 46 66 34 C64 28 72 24 74 18" />
      <path d="M50 50 C40 40 36 30 28 28" />
      <path d="M50 50 C60 40 64 30 72 28" />
      <path d="M34 34 C40 26 36 18 42 16" />
      <path d="M66 34 C60 26 64 18 58 16" />
    </Ink>
  );
}

function Tuyetaban() {
  return (
    <Ink>
      <path d="M42 16 C24 24 22 46 40 52 C52 56 24 64 32 86" />
      <path d="M58 16 C76 24 78 46 60 52 C48 56 76 64 68 86" />
    </Ink>
  );
}

function Qusqanat() {
  return (
    <Ink width={4.5}>
      <path d="M16 78 C40 62 62 36 88 16" />
      <path d="M20 86 C46 68 70 50 92 38" />
      <path d="M28 92 C52 78 74 64 94 56" />
      <path d="M16 78 C10 66 22 62 26 72" />
    </Ink>
  );
}

function QusTumsyq() {
  return (
    <Ink>
      <path d="M16 64 C28 40 38 36 36 54" />
      <path d="M40 64 C52 40 62 36 60 54" />
      <path d="M64 64 C76 40 86 36 84 54" />
    </Ink>
  );
}

function Aqqy() {
  return (
    <Ink width={4.6}>
      <path d="M28 82 C26 52 58 50 52 28 C48 14 66 12 72 26 C78 40 62 44 64 30" />
    </Ink>
  );
}

function Orkesh() {
  return (
    <Ink width={4.6}>
      <path d="M10 72 Q30 26 50 72 Q70 26 90 72" />
      <path d="M14 78 H86" />
    </Ink>
  );
}

function BotaKoz() {
  return (
    <g>
      <path
        d="M14 50 Q50 18 86 50 Q50 82 14 50 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="4.2"
      />
      <path
        d="M50 50 m-8 0 a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0"
        fill="none"
        stroke="currentColor"
        strokeWidth="3.4"
      />
      <circle cx="50" cy="50" r="2.5" fill="currentColor" />
    </g>
  );
}

function Zhylan() {
  return (
    <Ink>
      <path d="M8 58 C18 36 28 74 40 54 C52 34 62 74 74 52 C82 40 88 36 92 28" />
      <path d="M88 22 L96 30 L86 32" />
    </Ink>
  );
}

function Tumarsha() {
  return (
    <g fill="currentColor">
      <path
        fillRule="evenodd"
        d="M50 12 L88 84 L12 84 Z M50 34 L72 76 L28 76 Z"
      />
      <path d="M50 48 L62 74 L38 74 Z" />
    </g>
  );
}

function Tortqulaq() {
  const hook = "M0 0 C0 -18 -16 -24 -20 -12 C-24 -2 -12 2 -8 -8";
  return (
    <Ink width={4.2}>
      <rect x="38" y="38" width="24" height="24" />
      <path d={hook} transform="translate(50 38) rotate(-90)" />
      <path d={hook} transform="translate(62 50)" />
      <path d={hook} transform="translate(50 62) rotate(90)" />
      <path d={hook} transform="translate(38 50) rotate(180)" />
    </Ink>
  );
}

function Irek() {
  return (
    <Ink>
      <path d="M6 62 H22 V34 H38 V62 H54 V34 H70 V62 H86 V34 H96" />
    </Ink>
  );
}

function Shytirman() {
  return (
    <Ink width={3.6}>
      <path d="M50 50 H66 V34 H30 V70 H78 V22 H18 V82 H86" />
    </Ink>
  );
}

function Omyrtqa() {
  return (
    <Ink>
      <path d="M18 50 L32 36 L46 50 L32 64 Z" />
      <path d="M46 50 L60 34 L74 50 L60 66 Z" />
      <path d="M8 50 H18" />
      <path d="M74 50 H92" />
    </Ink>
  );
}

function Sharshy() {
  return (
    <Ink>
      <rect x="22" y="22" width="56" height="56" />
      <rect x="34" y="34" width="32" height="32" />
      <path d="M50 22 V34 M50 66 V78 M22 50 H34 M66 50 H78" />
    </Ink>
  );
}

function Shynzhyr() {
  return (
    <Ink>
      <ellipse cx="24" cy="50" rx="14" ry="18" />
      <ellipse cx="50" cy="50" rx="14" ry="18" />
      <ellipse cx="76" cy="50" rx="14" ry="18" />
    </Ink>
  );
}

function Gul() {
  return (
    <g fill="currentColor">
      {Array.from({ length: 8 }, (_, i) => (
        <ellipse
          key={i}
          cx="50"
          cy="24"
          rx="7"
          ry="16"
          transform={`rotate(${i * 45} 50 50)`}
        />
      ))}
      <circle cx="50" cy="50" r="7" fill="var(--color-bg)" />
      <circle cx="50" cy="50" r="3.5" />
    </g>
  );
}

function Zhapyraq() {
  return (
    <Ink>
      <path d="M50 86 C50 86 16 62 26 36 C34 16 50 12 50 12 C50 12 66 16 74 36 C84 62 50 86 50 86" />
      <path d="M50 78 V22" />
      <path d="M50 60 C38 54 32 46 30 38" />
      <path d="M50 60 C62 54 68 46 70 38" />
      <path d="M50 44 C40 40 36 34 36 28" />
      <path d="M50 44 C60 40 64 34 64 28" />
    </Ink>
  );
}

function UshZhapyraq() {
  const leaf = "M0 0 C-14 -6 -16 -28 0 -40 C16 -28 14 -6 0 0";
  return (
    <Ink>
      <path d={leaf} transform="translate(50 58)" />
      <path d={leaf} transform="translate(50 50) rotate(120)" />
      <path d={leaf} transform="translate(50 50) rotate(240)" />
    </Ink>
  );
}

function Agash() {
  return (
    <Ink>
      <path d="M50 88 V40" />
      <path d="M50 70 C32 66 22 52 28 40 C32 32 24 28 22 20" />
      <path d="M50 70 C68 66 78 52 72 40 C68 32 76 28 78 20" />
      <path d="M50 56 C36 44 34 30 24 26" />
      <path d="M50 56 C64 44 66 30 76 26" />
      <path d="M50 42 C42 30 44 18 50 12 C56 18 58 30 50 42" />
    </Ink>
  );
}

function Kun() {
  return (
    <Ink>
      <circle cx="50" cy="50" r="14" />
      <path d="M50 36 V28 M50 64 V72 M36 50 H28 M64 50 H72" />
      <path d="M40 40 L34 34 M60 40 L66 34 M40 60 L34 66 M60 60 L66 66" />
      <path d="M50 44 V56 M44 50 H56" />
    </Ink>
  );
}

function Ai() {
  return (
    <path
      fill="currentColor"
      fillRule="evenodd"
      d="M48 16 A34 34 0 1 0 48 84 A34 34 0 1 0 48 16 Z M64 22 A26 26 0 1 0 64 78 A26 26 0 1 0 64 22 Z"
    />
  );
}

const STAR =
  "M50 10 L56.1 35.2 L78.3 21.7 L64.8 43.9 L90 50 L64.8 56.1 L78.3 78.3 L56.1 64.8 L50 90 L43.9 64.8 L21.7 78.3 L35.2 56.1 L10 50 L35.2 43.9 L21.7 21.7 L43.9 35.2 Z";

function Zhuldyz() {
  return <path d={STAR} fill="currentColor" />;
}

const MARKS: Record<string, () => ReactNode> = {
  "qoshqar-muyiz": Qoshqar,
  "synar-muyiz": Synar,
  "qos-muyiz": Qos,
  "arqar-muyiz": Arqar,
  "qyryq-muyiz": Qyryq,
  "synyq-muyiz": Synyq,
  "maral-muyiz": Maral,
  tuyetaban: Tuyetaban,
  qusqanat: Qusqanat,
  "qus-tumsyq": QusTumsyq,
  "aqqy-moin": Aqqy,
  orkesh: Orkesh,
  "bota-koz": BotaKoz,
  "zhylan-iz": Zhylan,
  tumarsha: Tumarsha,
  tortqulaq: Tortqulaq,
  irek: Irek,
  shytirman: Shytirman,
  omyrqa: Omyrtqa,
  sharshy: Sharshy,
  shynzhyr: Shynzhyr,
  gul: Gul,
  zhapyraq: Zhapyraq,
  "ush-zhapyraq": UshZhapyraq,
  agash: Agash,
  kun: Kun,
  ai: Ai,
  zhuldyz: Zhuldyz,
};

export function OrnamentMark({
  id,
  className,
  title,
}: {
  id: string;
  className?: string;
  title?: string;
}) {
  const Mark = MARKS[id] ?? Qoshqar;
  return (
    <svg
      viewBox="0 0 100 100"
      className={cn("text-primary", className)}
      role={title ? "img" : "presentation"}
      aria-label={title || undefined}
      aria-hidden={title ? undefined : true}
    >
      <Mark />
    </svg>
  );
}

export function Medallion({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 200 200" className={className} aria-hidden="true">
      <circle cx="100" cy="100" r="96" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <circle cx="100" cy="100" r="88" fill="none" stroke="currentColor" strokeWidth="3" />
      <circle cx="100" cy="100" r="78" fill="none" stroke="currentColor" strokeWidth="1" />
      <g transform="translate(50 50)">
        <Tortqulaq />
      </g>
    </svg>
  );
}

export function Frieze({ className }: { className?: string }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg viewBox="0 0 360 28" className={cn("text-accent", className)} aria-hidden="true">
      <defs>
        <pattern id={id} width="48" height="28" patternUnits="userSpaceOnUse">
          <path
            d="M0 18 H12 V8 H24 V18 H36 V8 H48"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
          />
        </pattern>
      </defs>
      <rect width="360" height="28" fill={`url(#${id})`} />
    </svg>
  );
}

