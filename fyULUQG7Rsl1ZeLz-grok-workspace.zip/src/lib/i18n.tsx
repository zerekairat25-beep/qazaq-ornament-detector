import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "kk";
export type Bi = Record<Lang, string>;

type Ctx = {
  lang: Lang;
  setLang: (lang: Lang) => void;
  t: (copy: Bi) => string;
};

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    const saved = localStorage.getItem("qo-lang");
    if (saved === "kk" || saved === "en") setLangState(saved);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang === "kk" ? "kk" : "en";
  }, [lang]);

  const setLang = (next: Lang) => {
    setLangState(next);
    localStorage.setItem("qo-lang", next);
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t: (copy) => copy[lang] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useI18n outside provider");
  return ctx;
}
