import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell, Btn } from "@/components/shell";
import { OrnamentMark } from "@/components/ornament-mark";
import { ORNAMENTS, type Ornament } from "@/data/ornaments";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/learn")({ component: LearnPage });

type Question =
  | { kind: "name"; ornament: Ornament; options: Ornament[] }
  | { kind: "meaning"; ornament: Ornament; options: Ornament[] };

function LearnPage() {
  const { t } = useI18n();
  const [seed, setSeed] = useState<number | null>(null);
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [best, setBest] = useState<number | null>(null);

  const questions = useMemo(() => (seed === null ? [] : buildQuiz(seed)), [seed]);
  const current = questions[step];
  const done = seed !== null && step >= questions.length;

  function start() {
    const stored = Number(localStorage.getItem("qo-best"));
    setBest(Number.isFinite(stored) ? stored : null);
    setSeed(Date.now());
    setStep(0);
    setPicked(null);
    setScore(0);
  }

  function choose(id: string) {
    if (!current || picked) return;
    setPicked(id);
    if (id === current.ornament.id) setScore((value) => value + 1);
  }

  function next() {
    if (step + 1 >= questions.length) {
      const finalScore = score;
      const stored = Number(localStorage.getItem("qo-best"));
      const prior = Number.isFinite(stored) ? stored : 0;
      if (finalScore > prior) {
        localStorage.setItem("qo-best", String(finalScore));
        setBest(finalScore);
      } else if (Number.isFinite(stored)) {
        setBest(stored);
      }
    }
    setStep((value) => value + 1);
    setPicked(null);
  }

  return (
    <Shell>
      <div className="mx-auto max-w-3xl px-4 py-10">
        <p className="text-xs font-semibold tracking-widest text-accent uppercase">
          {t({ en: "The learning check", kk: "Білім сынағы" })}
        </p>
        <h1 className="mt-2 font-display text-5xl">
          {t({ en: "Name it, then say what it holds", kk: "Атаңыз, сосын не ұстайтынын айтыңыз" })}
        </h1>
        <p className="mt-4 text-sm leading-relaxed text-muted">
          {t({
            en: "The study gave the same kind of check before and after people used the system. Names rose from 38% to 92%, meanings from 24% to 85%, context from 31% to 88%. This round is eight questions from the atlas. It is practice, not that experiment.",
            kk: "Зерттеу адамдарға жүйені қолданғанға дейін және кейін осы тектес сынақ берген. Атау 38%-дан 92%-ға, мағына 24%-дан 85%-ға, контекст 31%-дан 88%-ға көтерілген. Бұл раунд — жинақтан сегіз сұрақ. Жаттығу, сол эксперимент емес.",
          })}
        </p>

        {seed === null ? (
          <div className="mt-8">
            <Btn onClick={start}>{t({ en: "Start eight questions", kk: "Сегіз сұрақты бастау" })}</Btn>
          </div>
        ) : null}

        {current && !done ? (
          <div className="mt-8 border border-line bg-surface p-5">
            <p className="text-xs font-semibold text-muted tabular-nums">
              {step + 1} / {questions.length}
            </p>
            <div className="mt-4 flex justify-center">
              <OrnamentMark id={current.ornament.id} className="size-36" title="" />
            </div>
            <h2 className="mt-4 text-center font-display text-3xl">
              {current.kind === "name"
                ? t({ en: "What is this called?", kk: "Бұл қалай аталады?" })
                : t({ en: "Which sense belongs to this form?", kk: "Бұл пішінге қай мән жатады?" })}
            </h2>
            {current.kind === "meaning" ? (
              <p className="mt-1 text-center text-muted">{t(current.ornament.name)}</p>
            ) : null}
            <ul className="mt-5 grid gap-2">
              {current.options.map((option) => {
                const correct = option.id === current.ornament.id;
                const show = picked !== null;
                return (
                  <li key={option.id}>
                    <button
                      type="button"
                      disabled={picked !== null}
                      onClick={() => choose(option.id)}
                      className={cn(
                        "min-h-11 w-full border px-3 py-3 text-left text-sm",
                        !show && "border-line bg-bg",
                        show && correct && "border-primary bg-primary text-primary-fg",
                        show && picked === option.id && !correct && "border-fg bg-fg text-bg",
                        show && picked !== option.id && !correct && "border-line text-muted",
                      )}
                    >
                      {current.kind === "name" ? t(option.name) : t(option.meaning)}
                    </button>
                  </li>
                );
              })}
            </ul>
            {picked ? (
              <div className="mt-4 flex items-center justify-between gap-3">
                <p className="text-sm">
                  {picked === current.ornament.id
                    ? t({ en: "Yes. That is the one.", kk: "Иә. Дәл осы." })
                    : t({ en: "Not that one. The marked answer is the record.", kk: "Ол емес. Белгіленгені — дерек." })}
                </p>
                <Btn onClick={next}>
                  {step + 1 === questions.length
                    ? t({ en: "See the score", kk: "Нәтижені көру" })
                    : t({ en: "Next", kk: "Келесі" })}
                </Btn>
              </div>
            ) : null}
          </div>
        ) : null}

        {done ? (
          <div className="mt-8 border border-line bg-fg p-6 text-bg">
            <p className="font-display text-6xl tabular-nums">
              {score}/{questions.length}
            </p>
            <p className="mt-2 text-bg/80">
              {t({
                en: "Eight is a short check. The study’s jump came after people had used the full desk, not after one round.",
                kk: "Сегіз — қысқа сынақ. Зерттеудегі секіріс адамдар толық үстелді қолданған соң болған, бір раундтан кейін емес.",
              })}
            </p>
            {best !== null ? (
              <p className="mt-2 text-sm text-accent">
                {t({ en: `Best on this device: ${best}/8`, kk: `Осы құрылғыдағы үздік: ${best}/8` })}
              </p>
            ) : null}
            <div className="mt-5 flex flex-wrap gap-3">
              <Btn onClick={start}>{t({ en: "Try another round", kk: "Тағы бір раунд" })}</Btn>
              <Btn href="/atlas" tone="quiet">
                {t({ en: "Read the atlas", kk: "Жинақты оқу" })}
              </Btn>
            </div>
          </div>
        ) : null}
      </div>
    </Shell>
  );
}

function buildQuiz(seed: number): Question[] {
  const rand = mulberry32(seed);
  const pool = shuffle(ORNAMENTS, rand);
  const nameSet = pool.slice(0, 4);
  const meaningSet = pool.slice(4, 8);
  const questions: Question[] = [
    ...nameSet.map((ornament) => ({
      kind: "name" as const,
      ornament,
      options: withDecoys(ornament, pool, rand),
    })),
    ...meaningSet.map((ornament) => ({
      kind: "meaning" as const,
      ornament,
      options: withDecoys(ornament, pool, rand),
    })),
  ];
  return shuffle(questions, rand);
}

function withDecoys(ornament: Ornament, pool: Ornament[], rand: () => number) {
  const same = pool.filter((item) => item.id !== ornament.id && item.category === ornament.category);
  const rest = pool.filter((item) => item.id !== ornament.id && item.category !== ornament.category);
  const decoys = shuffle([...same, ...rest], rand).slice(0, 3);
  return shuffle([ornament, ...decoys], rand);
}

function shuffle<T>(list: T[], rand: () => number) {
  const copy = [...list];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rand() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function rand() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
