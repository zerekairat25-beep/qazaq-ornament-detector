import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell } from "@/components/shell";
import { OrnamentMark } from "@/components/ornament-mark";
import { CATEGORIES, ORNAMENTS, SOURCE_LINE, type CategoryId, type Ornament } from "@/data/ornaments";
import { useI18n, type Bi } from "@/lib/i18n";
import { cn } from "@/lib/cn";

type Search = { cat?: CategoryId };

export const Route = createFileRoute("/atlas")({
  validateSearch: (search: Record<string, unknown>): Search => {
    const allowed: CategoryId[] = ["zoomorphic", "plant", "geometric", "cosmogonic"];
    if (typeof search.cat === "string" && allowed.includes(search.cat as CategoryId)) {
      return { cat: search.cat as CategoryId };
    }
    return {};
  },
  component: AtlasPage,
});

function AtlasPage() {
  const { cat } = Route.useSearch();
  const { t } = useI18n();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<CategoryId | "all">(cat ?? "all");
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    if (cat) setFilter(cat);
  }, [cat]);

  useEffect(() => {
    const hash = window.location.hash.replace("#", "");
    if (hash && ORNAMENTS.some((item) => item.id === hash)) {
      setOpenId(hash);
    }
  }, []);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ORNAMENTS.filter((item) => {
      if (filter !== "all" && item.category !== filter) return false;
      if (!q) return true;
      const blob = [item.name.en, item.name.kk, item.gloss.en, item.gloss.kk, item.meaning.en, item.meaning.kk]
        .join(" ")
        .toLowerCase();
      return blob.includes(q);
    });
  }, [filter, query]);

  const open = ORNAMENTS.find((item) => item.id === openId) ?? null;

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <p className="text-xs font-semibold tracking-widest text-accent uppercase">
          {t({ en: "The record", kk: "Дерек" })}
        </p>
        <h1 className="mt-2 font-display text-5xl md:text-6xl">
          {t({ en: "Ornament atlas", kk: "Ою жинағы" })}
        </h1>
        <p className="mt-4 max-w-2xl text-muted">{t(SOURCE_LINE)}</p>

        <div className="mt-8 flex flex-col gap-3 md:flex-row md:items-center">
          <label className="sr-only" htmlFor="ornament-search">
            {t({ en: "Search ornaments", kk: "Ою іздеу" })}
          </label>
          <input
            id="ornament-search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder={t({ en: "Search a name or a meaning", kk: "Атау не мағына іздеу" })}
            className="min-h-11 w-full border border-line bg-surface px-3 text-sm md:max-w-sm"
          />
          <div className="flex flex-wrap gap-2">
            <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
              {t({ en: "All", kk: "Бәрі" })}
            </FilterChip>
            {CATEGORIES.map((item) => (
              <FilterChip key={item.id} active={filter === item.id} onClick={() => setFilter(item.id)}>
                {t(item.label)}
              </FilterChip>
            ))}
          </div>
        </div>

        {open ? <Detail ornament={open} onClose={() => setOpenId(null)} /> : null}

        <ul className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
          {list.map((item) => (
            <li key={item.id} id={item.id}>
              <button
                type="button"
                onClick={() => {
                  setOpenId(item.id);
                  document.getElementById("ornament-detail")?.scrollIntoView({ block: "nearest" });
                }}
                className={cn(
                  "flex h-full w-full flex-col border bg-surface p-4 text-left transition-transform duration-150 ease-out active:scale-[0.98]",
                  openId === item.id ? "border-primary" : "border-line",
                )}
              >
                <OrnamentMark id={item.id} className="size-24" title={t(item.name)} />
                <span className="mt-3 font-display text-2xl">{t(item.name)}</span>
                <span className="text-sm text-muted">{t(item.gloss)}</span>
                {item.studied ? (
                  <span className="mt-3 text-xs font-semibold tracking-wide text-primary uppercase">
                    {t({ en: "In the control test", kk: "Бақылау сынағында" })}
                  </span>
                ) : null}
              </button>
            </li>
          ))}
        </ul>
        {list.length === 0 ? (
          <p className="mt-8 text-muted">
            {t({ en: "Nothing matches that search.", kk: "Іздеуге сай өрнек жоқ." })}
          </p>
        ) : null}
      </div>
    </Shell>
  );
}

function FilterChip({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "min-h-11 px-3 text-sm font-medium",
        active ? "bg-fg text-bg" : "border border-line bg-surface text-fg",
      )}
    >
      {children}
    </button>
  );
}

function Detail({ ornament, onClose }: { ornament: Ornament; onClose: () => void }) {
  const { t } = useI18n();
  const category = CATEGORIES.find((item) => item.id === ornament.category)!;
  const rows: { label: Bi; value: Bi }[] = [
    { label: { en: "Name", kk: "Ою атауы" }, value: ornament.name },
    { label: { en: "Category", kk: "Категориясы" }, value: category.label },
    { label: { en: "Graphic form", kk: "Графикалық пішіні" }, value: ornament.form },
    { label: { en: "Symmetry", kk: "Симметрия типі" }, value: ornament.symmetry },
    { label: { en: "Meaning", kk: "Семантикалық мәні" }, value: ornament.meaning },
    { label: { en: "Where it sits", kk: "Қолданылу контексті" }, value: ornament.use },
    {
      label: { en: "Source frame", kk: "Дереккөз негізі" },
      value: {
        en: "Janibekov’s four-part classification, as used in the study. Forms from published Kazakh ornament descriptions.",
        kk: "Зерттеу ұстанған Жәнібековтің төрттік жіктеуі. Пішіндер жарияланған қазақ ою сипаттамаларынан.",
      },
    },
  ];

  return (
    <article id="ornament-detail" className="mt-6 border border-line bg-surface p-5 md:p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold tracking-wide text-accent uppercase">{t(ornament.gloss)}</p>
          <h2 className="font-display text-4xl">{t(ornament.name)}</h2>
        </div>
        <button type="button" onClick={onClose} className="min-h-11 px-3 text-sm text-muted">
          {t({ en: "Close", kk: "Жабу" })}
        </button>
      </div>
      <div className="mt-4 grid gap-6 md:grid-cols-[180px_1fr]">
        <div className="flex items-center justify-center border border-line bg-bg p-4">
          <OrnamentMark id={ornament.id} className="size-36" title={t(ornament.name)} />
        </div>
        <dl className="divide-y divide-line">
          {rows.map((row) => (
            <div key={row.label.en} className="grid gap-1 py-3 md:grid-cols-[160px_1fr]">
              <dt className="text-xs font-semibold tracking-wide text-accent uppercase">{t(row.label)}</dt>
              <dd className="text-sm leading-relaxed">{t(row.value)}</dd>
            </div>
          ))}
        </dl>
      </div>
      {ornament.control ? (
        <p className="mt-4 text-sm text-muted">
          {t({
            en: `Control test: ${ornament.control.correct} of ${ornament.control.images} images named correctly. The study text prints ${ornament.control.printed}%.`,
            kk: `Бақылау сынағы: ${ornament.control.images} суреттің ${ornament.control.correct}-і дұрыс аталды. Зерттеу мәтінінде ${ornament.control.printed}% деп жазылған.`,
          })}
        </p>
      ) : null}
    </article>
  );
}
