import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell, Btn } from "@/components/shell";
import { Frieze, Medallion, OrnamentMark } from "@/components/ornament-mark";
import { ORNAMENTS, CATEGORIES } from "@/data/ornaments";
import { useI18n } from "@/lib/i18n";

export const Route = createFileRoute("/")({ component: Home });

const FEATURED = ["qoshqar-muyiz", "tumarsha", "qusqanat", "tuyetaban", "tortqulaq", "kun"];

function Home() {
  const { t } = useI18n();
  const featured = FEATURED.map((id) => ORNAMENTS.find((item) => item.id === id)!);

  return (
    <Shell>
      <section className="bg-fg text-bg">
        <div className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-14 md:grid-cols-2 md:py-20">
          <div className="order-2 md:order-1">
            <p className="enter text-xs font-semibold tracking-widest text-accent uppercase">
              Qazaq Ornament AI
            </p>
            <h1 className="enter enter-2 mt-4 font-display text-5xl leading-none text-bg md:text-7xl">
              {t({
                en: "Name the ornament. Keep the meaning.",
                kk: "Оюды ата. Мағынасын қалдыр.",
              })}
            </h1>
            <p className="enter enter-3 mt-5 max-w-xl text-base leading-relaxed text-bg/80">
              {t({
                en: "Kazakh oyu-örnek, read the way the study sets it out: Janibekov’s classes, a standard record for each motif, then a picture you can ask about.",
                kk: "Қазақ ою-өрнегі зерттеудегі ретпен: Жәнібеков жіктеуі, әр өрнектің стандартты карточкасы, сосын сұрауға болатын сурет.",
              })}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Btn href="/identify">
                {t({ en: "Identify a photo", kk: "Суретті тану" })}
              </Btn>
              <Link
                to="/atlas"
                className="inline-flex min-h-11 items-center justify-center border border-bg/30 px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                {t({ en: "Open the atlas", kk: "Жинақты ашу" })}
              </Link>
            </div>
          </div>
          <div className="order-1 flex justify-center md:order-2">
            <Medallion className="enter size-64 text-accent md:size-80" />
          </div>
        </div>
        <Frieze className="h-7 w-full text-accent" />
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="font-display text-4xl">
          {t({ en: "Three jobs, one desk", kk: "Үш міндет, бір үстел" })}
        </h2>
        <p className="mt-3 max-w-2xl text-muted">
          {t({
            en: "The study’s result is not a label by itself. Recognition, meaning, and plain speech stay together.",
            kk: "Зерттеудің нәтижесі — жалаң атау емес. Тану, мағына және қарапайым сөз бірге тұрады.",
          })}
        </p>
        <ol className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            {
              n: "01",
              title: { en: "See the form", kk: "Пішінді көру" },
              body: {
                en: "A photo goes in. The motif is matched by its contour: horn, triangle, wing, track.",
                kk: "Сурет кіреді. Өрнек контурымен сәйкеседі: мүйіз, үшбұрыш, қанат, із.",
              },
            },
            {
              n: "02",
              title: { en: "Attach the record", kk: "Карточканы қосу" },
              body: {
                en: "The name pulls a fixed card: category, symmetry, meaning, and where the motif sits on an object.",
                kk: "Атау бекітілген карточканы ашады: санат, симметрия, мағына және бұйымдағы орны.",
              },
            },
            {
              n: "03",
              title: { en: "Say it plainly", kk: "Анық айту" },
              body: {
                en: "The screen gives the traditional name and the sense, in Kazakh or English, without a fog of jargon.",
                kk: "Экран дәстүрлі атау мен мәнін қазақша не ағылшынша, термин тұманынсыз береді.",
              },
            },
          ].map((step) => (
            <li key={step.n} className="border border-line bg-surface p-5">
              <p className="font-display text-3xl text-accent">{step.n}</p>
              <h3 className="mt-2 text-2xl">{t(step.title)}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{t(step.body)}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-14 md:grid-cols-4">
          {[
            {
              k: "40+",
              v: {
                en: "motif types gathered from the ethnographic literature before the set was standardized",
                kk: "стандарттаудан бұрын этнографиялық әдебиеттен жиналған өрнек түрі",
              },
            },
            {
              k: "19/20",
              v: {
                en: "qoshqar muyiz images named correctly in the control set",
                kk: "бақылау жиынында дұрыс аталған қошқармүйіз суреті",
              },
            },
            {
              k: "38 → 92",
              v: {
                en: "percent who could name motifs before, then after, using the system",
                kk: "жүйені қолданғанға дейін және кейін өрнек атауын білгендердің пайызы",
              },
            },
            {
              k: "4",
              v: {
                en: "Janibekov classes: animal, plant, geometric, sky",
                kk: "Жәнібеков тобы: жануар, өсімдік, геометрия, аспан",
              },
            },
          ].map((item) => (
            <div key={item.k}>
              <p className="font-display text-5xl tabular-nums text-primary">{item.k}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted">{t(item.v)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="font-display text-4xl">
            {t({ en: "Start with six", kk: "Алтыдан бастаңыз" })}
          </h2>
          <Btn href="/atlas" tone="ghost">
            {t({ en: "All motifs", kk: "Барлық өрнек" })}
          </Btn>
        </div>
        <ul className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
          {featured.map((item) => (
            <li key={item.id}>
              <Link
                to="/atlas"
                hash={item.id}
                className="flex h-full flex-col border border-line bg-surface p-4 transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                <OrnamentMark id={item.id} className="size-24" title={t(item.name)} />
                <p className="mt-3 font-display text-2xl">{t(item.name)}</p>
                <p className="text-sm text-muted">{t(item.gloss)}</p>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="font-display text-4xl">
          {t({ en: "Four families", kk: "Төрт әулет" })}
        </h2>
        <div className="mt-6 grid gap-3 md:grid-cols-4">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.id}
              to="/atlas"
              search={{ cat: cat.id }}
              className="border border-line p-4"
            >
              <h3 className="text-2xl">{t(cat.label)}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{t(cat.note)}</p>
            </Link>
          ))}
        </div>
      </section>
    </Shell>
  );
}
