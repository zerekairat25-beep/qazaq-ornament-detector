import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell, Btn } from "@/components/shell";
import { OrnamentMark } from "@/components/ornament-mark";
import { CATEGORIES, ORNAMENTS, ornamentById } from "@/data/ornaments";
import { useI18n } from "@/lib/i18n";
import { identifyOrnament, type IdentifyOk } from "@/lib/identify.functions";

export const Route = createFileRoute("/identify")({ component: IdentifyPage });

function IdentifyPage() {
  const { t, lang } = useI18n();
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<IdentifyOk | null>(null);

  async function onFile(file: File | undefined) {
    if (!file) return;
    if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
      setError(t({ en: "Use a JPG, PNG, or WebP.", kk: "JPG, PNG не WebP жүктеңіз." }));
      return;
    }
    setError(null);
    setResult(null);
    setBusy(true);
    try {
      const image = await shrink(file);
      setPreview(image);
      const response = await identifyOrnament({ data: { image, lang } });
      if (!response.ok) {
        setError(response.error);
        return;
      }
      setResult(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : t({ en: "Could not read that file.", kk: "Файл оқылмады." }));
    } finally {
      setBusy(false);
    }
  }

  const match = result ? ornamentById(result.id) : undefined;

  return (
    <Shell>
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[1fr_1fr]">
        <div>
          <p className="text-xs font-semibold tracking-widest text-accent uppercase">
            {t({ en: "Recognition desk", kk: "Тану үстелі" })}
          </p>
          <h1 className="mt-2 font-display text-5xl">
            {t({ en: "Ask a picture", kk: "Суреттен сұраңыз" })}
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            {t({
              en: "The photo is matched to this catalog by shape. The meaning you then see is the catalog’s, not a free explanation. The study’s own ResNet or MobileNet weights are not running here. Similar horns were the hard cases in the control test.",
              kk: "Сурет пішіні бойынша осы жинаққа сәйкеседі. Кейін көретін мағына жинақтікі, еркін түсіндірме емес. Зерттеудегі ResNet не MobileNet салмақтары мұнда жұмыс істемейді. Бақылауда ең қиыны ұқсас мүйіздер болған.",
            })}
          </p>

          <label
            className="mt-6 flex min-h-52 cursor-pointer flex-col items-center justify-center border border-dashed border-accent bg-surface px-4 py-8 text-center"
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              void onFile(event.dataTransfer.files[0]);
            }}
          >
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="sr-only"
              onChange={(event) => void onFile(event.target.files?.[0])}
            />
            {preview ? (
              <img src={preview} alt="" className="max-h-48 object-contain" />
            ) : (
              <>
                <OrnamentMark id="qoshqar-muyiz" className="size-16 text-accent" />
                <p className="mt-3 font-medium">
                  {t({ en: "Drop a photo, or choose one", kk: "Суретті тастаңыз не таңдаңыз" })}
                </p>
                <p className="mt-1 text-sm text-muted">
                  {t({
                    en: "A single motif, filling the frame, works better than a whole carpet.",
                    kk: "Тұтас кілемнен гөрі кадрды толтырған бір өрнек дәлірек.",
                  })}
                </p>
              </>
            )}
          </label>
          <div className="mt-4">
            <Btn disabled={busy} onClick={() => document.querySelector<HTMLInputElement>('input[type="file"]')?.click()}>
              {busy
                ? t({ en: "Reading the picture…", kk: "Сурет оқылып жатыр…" })
                : t({ en: "Choose a photo", kk: "Сурет таңдау" })}
            </Btn>
          </div>
          {error ? <p className="mt-4 text-sm text-primary">{error}</p> : null}

          <ol className="mt-8 space-y-3 text-sm text-muted">
            {[
              {
                en: "The picture is sent once, when you ask.",
                kk: "Сурет сіз сұрағанда бір рет жіберіледі.",
              },
              {
                en: "It is scaled down, then classed against the catalog.",
                kk: "Ол кішірейтіледі, сосын жинақпен салыстырылады.",
              },
              {
                en: "The class opens the fixed card: name, meaning, place.",
                kk: "Класс бекітілген карточканы ашады: атау, мағына, орын.",
              },
            ].map((step, index) => (
              <li key={step.en} className="flex gap-3">
                <span className="font-display text-2xl text-accent">{index + 1}</span>
                <span className="pt-1">{t(step)}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="border border-line bg-surface p-5">
          {!result ? (
            <div>
              <h2 className="font-display text-3xl">
                {t({ en: "Five classes from the test", kk: "Сынақтағы бес класс" })}
              </h2>
              <p className="mt-2 text-sm text-muted">
                {t({
                  en: "These are the motifs the study measured. Open one in the atlas while you wait.",
                  kk: "Зерттеу өлшеген өрнектер осылар. Күтіп тұрғанда жинақтан ашыңыз.",
                })}
              </p>
              <ul className="mt-4 grid grid-cols-2 gap-3">
                {ORNAMENTS.filter((item) => item.studied).map((item) => (
                  <li key={item.id} className="border border-line p-3">
                    <OrnamentMark id={item.id} className="size-16" title={t(item.name)} />
                    <p className="mt-2 font-display text-xl">{t(item.name)}</p>
                    <p className="text-xs text-muted">
                      {item.control ? `${item.control.correct}/${item.control.images}` : ""}
                    </p>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <Result result={result} />
          )}
        </div>
      </div>
    </Shell>
  );
}

function Result({ result }: { result: IdentifyOk }) {
  const { t } = useI18n();
  const ornament = ornamentById(result.id);
  const pct = Math.round(result.confidence * 100);

  if (!ornament) {
    return (
      <div>
        <h2 className="font-display text-3xl">
          {t({ en: "No single motif dominated", kk: "Бір өрнек басым болмады" })}
        </h2>
        {result.observation ? <p className="mt-3 text-sm leading-relaxed">{result.observation}</p> : null}
        <p className="mt-3 text-sm text-muted">
          {t({
            en: "Crop closer to one motif, or look through the atlas. A whole carpet is a crowd of signs.",
            kk: "Бір өрнекке жақындатып қиыңыз не жинақты қараңыз. Тұтас кілем — белгілердің жиыны.",
          })}
        </p>
      </div>
    );
  }

  const category = CATEGORIES.find((item) => item.id === ornament.category)!;

  return (
    <div>
      <p className="text-xs font-semibold tracking-wide text-accent uppercase">
        {t(category.label)} · {pct}%
      </p>
      <div className="mt-2 h-1.5 bg-line">
        <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
      </div>
      <div className="mt-4 flex items-center gap-4">
        <OrnamentMark id={ornament.id} className="size-24" title={t(ornament.name)} />
        <div>
          <h2 className="font-display text-4xl">{t(ornament.name)}</h2>
          <p className="text-muted">{t(ornament.gloss)}</p>
        </div>
      </div>
      {result.observation ? <p className="mt-4 text-sm leading-relaxed">{result.observation}</p> : null}
      {pct < 45 ? (
        <p className="mt-3 text-sm text-primary">
          {t({
            en: "Low confidence. Horn motifs were easy to mix up in the study too. Compare the atlas.",
            kk: "Сенім төмен. Зерттеуде де мүйіз өрнектер шатасқан. Жинақпен салыстырыңыз.",
          })}
        </p>
      ) : null}
      <h3 className="mt-5 font-display text-2xl">{t({ en: "Meaning", kk: "Мағынасы" })}</h3>
      <p className="mt-2 text-sm leading-relaxed">{t(ornament.meaning)}</p>
      <h3 className="mt-5 font-display text-2xl">{t({ en: "Form", kk: "Пішіні" })}</h3>
      <p className="mt-2 text-sm leading-relaxed">{t(ornament.form)}</p>
      <h3 className="mt-5 font-display text-2xl">{t({ en: "Where it sits", kk: "Қайда тұрады" })}</h3>
      <p className="mt-2 text-sm leading-relaxed">{t(ornament.use)}</p>
      {result.alternates.length > 0 ? (
        <div className="mt-5">
          <p className="text-xs font-semibold tracking-wide text-muted uppercase">
            {t({ en: "Also considered", kk: "Тағы қаралғаны" })}
          </p>
          <ul className="mt-2 flex flex-wrap gap-2">
            {result.alternates.map((alt) => {
              const other = ornamentById(alt.id);
              if (!other) return null;
              return (
                <li key={alt.id} className="border border-line px-3 py-2 text-sm">
                  {t(other.name)} · {Math.round(alt.confidence * 100)}%
                </li>
              );
            })}
          </ul>
        </div>
      ) : null}
      <div className="mt-6">
        <Btn href="/atlas" tone="quiet">
          {t({ en: "See it in the atlas", kk: "Жинақтан көру" })}
        </Btn>
      </div>
    </div>
  );
}

async function shrink(file: File) {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 768 / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not prepare the picture");
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  return canvas.toDataURL("image/jpeg", 0.82);
}
